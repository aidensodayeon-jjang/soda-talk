export const SODABOT_FIRMWARE_SOURCE = `// SODABOT BASIC: ESP32-S3, BLE/Wi-Fi/USB 명령 및 기본 표정
#include <Arduino.h>
#include <atomic>
#include <math.h>
#if !ARDUINO_USB_CDC_ON_BOOT
#error "Enable Tools > USB CDC On Boot before uploading this sketch."
#endif
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <driver/i2s.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <SPI.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <esp_heap_caps.h>

// === CUSTOM_HEADERS_START ===
// === CUSTOM_HEADERS_END ===

const char* ssid = "Dlab_2G";
const char* password = "academy!";

// 기본 위치 설정 (서울 기준)
const char* WEATHER_LATITUDE  = "37.5665";
const char* WEATHER_LONGITUDE = "126.9780";

// === CUSTOM_GLOBALS_START ===
// === CUSTOM_GLOBALS_END ===

struct IncomingMessage { char json[2048]; uint32_t clientId; uint8_t source; };
void processMessage(const IncomingMessage& message);
AsyncWebServer server(8080);
AsyncWebSocket ws("/soda/ws");
QueueHandle_t incomingQueue;
bool webServerStarted = false;
// BLE UUID definitions matching web app
#define SERVICE_UUID        "6b8a0001-4f2a-4b3c-9d5e-1a2b3c4d5e6f"
#define CHAR_WRITE_UUID     "6b8a0002-4f2a-4b3c-9d5e-1a2b3c4d5e6f"
#define CHAR_NOTIFY_UUID    "6b8a0003-4f2a-4b3c-9d5e-1a2b3c4d5e6f"
const char* SODA_BLE_NAME = "SODABOT_aiden";

BLEServer* pServer = NULL;
BLECharacteristic* pNotifyCharacteristic = NULL;
bool deviceConnected = false;


// === SODA-AIBOT v1.1 PCB + J1 버튼 (soda-aibot의 실물 SuperMini 핀 순서 기준) ===
// 실물 헤더: 좌=TX(43) RX(44) 1 2 3 4 5 6 7,  우=5V G 3V3 13 12 11 10 9 8
// J1.1 SIG → J5.1 → 실물 TX/GPIO43. J1.3 GND와 순간 누름 버튼 연결.
// J1.2 3V3는 2선식 버튼에 연결하지 않는다. INPUT_PULLUP, 누르면 LOW.
// PCB 좌측 실크 1~9와 실물 GPIO 번호는 다르므로 소스의 실물 핀 순서를 따른다.
#define BUTTON_PIN 43

#define MIC_I2S_PORT I2S_NUM_1

#define MIC_SCK  5
#define MIC_WS   4
#define MIC_SD   3
#define MIC_GAIN 2  // DC 제거 후 증폭. 실측 잘림을 줄이기 위해 4배에서 낮춤

#define MIC_SAMPLE_RATE 16000
constexpr uint32_t MAX_RECORD_SECONDS = 8;
constexpr uint32_t MIN_RECORD_MS = 350;
constexpr size_t MAX_RECORD_SAMPLES = MIC_SAMPLE_RATE * MAX_RECORD_SECONDS;

// soda-talk 서버가 실행되는 컴퓨터의 현재 Wi-Fi 주소.
// 컴퓨터 IP가 바뀌면 이 값만 고치면 된다.
const char* SODA_SERVER_HOST = "sodabot.sodayeon.co.kr";
const uint16_t SODA_SERVER_PORT = 7989;
const char* SODA_AUDIO_CHAT_PATH = "/api/hw/audio-chat";
const char* SODA_TTS_PATH = "/api/hw/tts";
const char* DEFAULT_SODA_API_KEY = "sk-soda-33b8c4c9312d29b8a01f1803e890a758";
String sodaApiKey;

bool micReady = false;
int16_t* voicePcm = nullptr;
size_t voiceCapacitySamples = 0;
volatile size_t voiceSampleCount = 0;
std::atomic<bool> voiceUploadPending{false};
std::atomic<bool> voiceUploadBusy{false};
std::atomic<bool> voiceRecording{false};
// 최근 약 0.5초의 마이크 측정값. 무음/발화 비교용이며 RMS만으로 발화를 판정하지 않는다.
std::atomic<int> micLevelRms{0}, micLevelMean{0}, micLevelPeak{0}, micClipPermille{0};
std::atomic<uint32_t> micLevelUpdatedAt{0};
int32_t micRawProbe[256];
std::atomic<int> micProbeState{0}; // 0 idle, 1 requested, 2 ready
size_t micProbeCount = 0;

void setupMicrophone() {
  i2s_config_t config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = MIC_SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false
  };
  i2s_pin_config_t pins = {
    .mck_io_num = I2S_PIN_NO_CHANGE,
    .bck_io_num = MIC_SCK,
    .ws_io_num = MIC_WS,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = MIC_SD
  };
  esp_err_t err = i2s_driver_install(MIC_I2S_PORT, &config, 0, NULL);
  if (err != ESP_OK) {
    Serial.printf("[오류] 마이크를 시작하지 못했습니다. 오류 코드: %s\\n", esp_err_to_name(err));
    return;
  }
  err = i2s_set_pin(MIC_I2S_PORT, &pins);
  if (err != ESP_OK) {
    Serial.printf("[오류] 마이크 핀 설정에 실패했습니다. 배선을 확인해주세요. 오류 코드: %s\\n", esp_err_to_name(err));
    i2s_driver_uninstall(MIC_I2S_PORT);
    return;
  }

  voiceCapacitySamples = MAX_RECORD_SAMPLES;
  voicePcm = static_cast<int16_t*>(heap_caps_malloc(
    voiceCapacitySamples * sizeof(int16_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  bool externalRam = voicePcm != nullptr;
  if (!voicePcm) {
    // Wi-Fi/BLE 및 서버 응답용 내부 힙을 남기고 최대 2초까지 녹음한다.
    const uint32_t caps = MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT;
    const size_t reserveBytes = 48 * 1024;
    size_t freeBytes = heap_caps_get_free_size(caps);
    size_t available = freeBytes > reserveBytes ? freeBytes - reserveBytes : 0;
    available = min(available, heap_caps_get_largest_free_block(caps));
    size_t targetSamples = min(available / sizeof(int16_t), size_t(MIC_SAMPLE_RATE * 2));
    // 0.1초 단위로 내림. 최소 1초를 확보하지 못하면 명확하게 오류 처리한다.
    voiceCapacitySamples = (targetSamples / 1600) * 1600;
    if (voiceCapacitySamples >= MIC_SAMPLE_RATE) {
      voicePcm = static_cast<int16_t*>(heap_caps_malloc(
        voiceCapacitySamples * sizeof(int16_t), caps));
    }
  }
  if (!voicePcm) {
    voiceCapacitySamples = 0;
    Serial.println("[오류] 녹음 메모리가 부족합니다. HARDWARE_STATUS로 메모리를 확인해주세요.");
    i2s_driver_uninstall(MIC_I2S_PORT);
    return;
  }
  micReady = true;
  Serial.printf("[준비] 마이크 / %s / 최대 %.1f초 / %.0fKB 녹음 버퍼\\n",
                externalRam ? "PSRAM" : "내부 RAM (PSRAM 사용 불가)",
                voiceCapacitySamples / float(MIC_SAMPLE_RATE),
                (voiceCapacitySamples * sizeof(int16_t)) / 1024.0);
}

// v1.1 PCB J4.7 LCD_CS → J8.2 → GPIO10 (서보용으로 사용하지 않는다).
#define TFT_CS   10
#define TFT_RST  6   // LCD RES = GPIO6 (좌 8번째 핀)
#define TFT_DC   7   // LCD DC  = GPIO7 (좌 9번째 핀)
#define TFT_MOSI 11
#define TFT_CLK  12

#define I2S_SPK_BCLK 2
#define I2S_SPK_LRC  1
#define I2S_SPK_DOUT 44
#define TTS_SAMPLE_RATE 24000
#define SPEAKER_VOLUME_PERCENT 55
#define SPEAKER_SAFE_PEAK 20000

// ... (전체 소스코드 포함)
`;

export const PINOUT_SPECS = [
  { group: 'J1 순간 누름 버튼', pin: 'GPIO 43 (TX)', function: 'INPUT_PULLUP (SIG-GND 연결 시 LOW), 음성 녹음 및 1회/2회/길게 누름 제어' },
  { group: 'ST7789 2.0" SPI LCD', pin: 'GPIO 10 (CS)', function: 'Chip Select (J8.2 연결)' },
  { group: 'ST7789 2.0" SPI LCD', pin: 'GPIO 6 (RST)', function: 'Hardware Reset (좌측 8번째 핀)' },
  { group: 'ST7789 2.0" SPI LCD', pin: 'GPIO 7 (DC)', function: 'Data / Command 선택 (좌측 9번째 핀)' },
  { group: 'ST7789 2.0" SPI LCD', pin: 'GPIO 11 (MOSI)', function: 'SPI Master Out Slave In 데이터 선' },
  { group: 'ST7789 2.0" SPI LCD', pin: 'GPIO 12 (CLK)', function: 'SPI Clock (40MHz 고속 구동)' },
  { group: 'INMP441 I2S 마이크', pin: 'GPIO 5 (SCK)', function: 'I2S_NUM_1 BCLK (16kHz 32bit 모노)' },
  { group: 'INMP441 I2S 마이크', pin: 'GPIO 4 (WS)', function: 'I2S_NUM_1 Word Select (Left Channel)' },
  { group: 'INMP441 I2S 마이크', pin: 'GPIO 3 (SD)', function: 'I2S_NUM_1 Serial Data Input' },
  { group: 'MAX98357A I2S 스피커', pin: 'GPIO 2 (BCLK)', function: 'I2S_NUM_0 Bit Clock (24kHz 16bit)' },
  { group: 'MAX98357A I2S 스피커', pin: 'GPIO 1 (LRC)', function: 'I2S_NUM_0 Left/Right Clock' },
  { group: 'MAX98357A I2S 스피커', pin: 'GPIO 44 (DIN/RX)', function: 'I2S_NUM_0 Data Output (UART0 해제 후 할당)' },
];

export const ARDUINO_SETTINGS = [
  { item: '보드 선택 (Board)', value: 'ESP32S3 Dev Module' },
  { item: 'USB CDC On Boot', value: 'Enabled (필수: 비활성화 시 컴파일 에러 발생)' },
  { item: 'Flash Size', value: '8MB (64Mb) 또는 16MB' },
  { item: 'Partition Scheme', value: 'Huge APP (3MB No OTA/1MB SPIFFS)' },
  { item: 'PSRAM', value: 'OPI PSRAM (ESP32-S3 N8R8 / N16R8 기준)' },
  { item: 'Upload Speed', value: '921600' },
  { item: '필요 라이브러리', value: 'Adafruit ST7735 and ST7789, Adafruit GFX, ArduinoJson (v6/v7), ESPAsyncWebServer, AsyncTCP' },
];
