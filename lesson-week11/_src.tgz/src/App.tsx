import { preventImeSubmit } from './utils/chatInput';
import { normalizeFriendSettings, friendToneInstruction } from './utils/friendSettings';
import { sodabotTransport } from './utils/sodabotTransport';
import { renderTextToBitmapPayload } from './utils/textBitmapRenderer';
import React, { useState, useEffect, useRef } from "react";
import AuthScreen from "./components/AuthScreen";
import SodabotConnectScreen from "./components/SodabotConnectScreen";
import SodabotSettingsScreen from "./components/SodabotSettingsScreen";
import SodabotFriendSettingsScreen from "./components/SodabotFriendSettingsScreen";
import SodabotWelcomeScreen from "./components/SodabotWelcomeScreen";
import SodabotMobileGuideScreen from "./components/SodabotMobileGuideScreen";
import SodabotAssemblyScreen from "./components/SodabotAssemblyScreen";
import { SodabotFriendsScreen } from "./components/SodabotFriendsScreen";
import SodaAiLabScreen from "./components/SodaAiLabScreen";
import SodaAiSkillScreen from "./components/SodaAiSkillScreen";
import DevCodeHubScreen from "./components/DevCodeHubScreen";
import AdminCourseManagerModal from "./components/AdminCourseManagerModal";
import MobileBottomTabBar, { MobileTab } from "./components/mobile/MobileBottomTabBar";
import MobileHomeScreen from "./components/mobile/MobileHomeScreen";
import MobileControlScreen from "./components/mobile/MobileControlScreen";
import PwaInstallBanner from "./components/mobile/PwaInstallBanner";
import soda63Code from "../firmware/soda-6-3.ino?raw";
import soda81Code from "../firmware/soda-8-1.ino?raw";
import soda91Code from "../firmware/soda-9-1.ino?raw";
import {
  Sparkles,
  Plus,
  Trash2,
  Settings,
  LogOut,
  Send,
  Terminal,
  User,
  Cpu,
  Bot,
  Wifi,
  WifiOff,
  Check,
  RefreshCw,
  Compass,
  MessageSquare,
  BookOpen,
  ArrowRight,
  X,
  Info,
  Sun,
  ChevronDown,
  ChevronRight,
  FileText,
  Zap,
  Users,
  Key,
  PlusCircle,
  Activity,
  Bluetooth,
  Smile,
  CheckCircle2,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Image as ImageIcon,
  Library,
  Usb,
  Smartphone,
  QrCode,
  Wrench,
  Folder,
  FolderOpen,
  FolderCode,
  FileCode,
  Code2,
  Copy,
  Download,
  Palette,
  ExternalLink,
  RotateCcw,
  Edit3
} from "lucide-react";
import { ChatRoom, Message, LMStudioConfig, CourseContent } from "./types";

// Temporarily hide manual playback of chat answers on the robot.
const SHOW_SODABOT_VOICE_PLAYBACK = false;

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem("authSessionId"));
  const [user, setUser] = useState<{ id: string; username: string; displayName: string; role?: string; canAccessChat?: boolean; personalApiKey?: string; friendSettings?: any } | null>(null);
  const [settingsVersion, setSettingsVersion] = useState<number>(0);

  // Helper for natural Korean postposition particles
  const getJosa = (word: string, type: '은는' | '을를' | '이가' | '아야' | '이야'): string => {
    if (!word) return '';
    const lastChar = word.charCodeAt(word.length - 1);
    const isHangul = lastChar >= 0xac00 && lastChar <= 0xd7a3;
    const hasJong = isHangul ? (lastChar - 0xac00) % 28 > 0 : true;

    switch (type) {
      case '은는': return hasJong ? `${word}은` : `${word}는`;
      case '을를': return hasJong ? `${word}을` : `${word}를`;
      case '이가': return hasJong ? `${word}이` : `${word}가`;
      case '아야': return hasJong ? `${word}아` : `${word}야`;
      case '이야': return hasJong ? `${word}이야` : `${word}야`;
      default: return word;
    }
  };

  // Helper: Always fetch latest Friend Settings, Profile, and Memories
  const getLatestFriendSettings = () => {
    const userKey = user?.id || user?.username || 'default';
    if (user?.friendSettings) return normalizeFriendSettings(user.friendSettings, user.displayName);
    try {
      return normalizeFriendSettings({
        persona: JSON.parse(localStorage.getItem(`sodabot_${userKey}_friend_persona`) || 'null'),
        profile: JSON.parse(localStorage.getItem(`sodabot_${userKey}_friend_profile`) || 'null'),
        memories: JSON.parse(localStorage.getItem(`sodabot_${userKey}_friend_memories`) || '[]'),
      }, user?.displayName);
    } catch { return normalizeFriendSettings({}, user?.displayName); }
  };

  // Main Navigation Tab: 'dev' (수업 & 펌웨어 개발실) vs 'chat' (소다봇 제어 & AI 코딩)
  const [mainNavTab, setMainNavTab] = useState<'dev' | 'chat'>('dev');

  // Dev Code Hub Tree States
  const [courseContents, setCourseContents] = useState<CourseContent[]>([]);
  const [expandedWeeks, setExpandedWeeks] = useState<number[]>([1]);
  const [isWeek67Expanded, setIsWeek67Expanded] = useState<boolean>(true);
  const [isWeek8Expanded, setIsWeek8Expanded] = useState<boolean>(true);
  const [isWeek9Expanded, setIsWeek9Expanded] = useState<boolean>(true);
  const [selectedDevCodeId, setSelectedDevCodeId] = useState<string>("content-week-1-sound");

  // Load course contents on mount
  useEffect(() => {
    fetch("/api/course-contents")
      .then(res => res.json())
      .then(data => {
        if (data.contents && data.contents.length > 0) {
          setCourseContents(data.contents);
          setSelectedDevCodeId(data.contents[0].id);
        }
      })
      .catch(console.error);
  }, []);

  // Admin Course Manager Modal State
  const [showCourseManager, setShowCourseManager] = useState(false);

  // Core Data States
  const [chats, setChats] = useState<ChatRoom[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'welcome' | 'chat' | 'sodabot' | 'settings' | 'sodabot_builder' | 'mic_circuit' | 'mic_lab' | 'firmware_v4' | 'firmware_v8' | 'firmware_v9' | 'assembly_v9' | 'ai_skills' | 'dev' | 'friends' | 'mobile_guide'>('welcome');
  const [inputText, setInputText] = useState("");
  const [sending, setSending] = useState(false);
  const [clearingChat, setClearingChat] = useState(false);

  // Mobile Layout & Responsive State
  const [isMobile, setIsMobile] = useState<boolean>(() => typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [mobileTab, setMobileTab] = useState<MobileTab>('home');

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Real Hardware Connection States
  const [sodabotIp, setSodabotIp] = useState<string | null>(localStorage.getItem("sodabot_robot_ip"));
  const [connType, setConnType] = useState<'none' | 'wifi' | 'serial' | 'ble'>(sodabotTransport.type);
  const [isVerifying, setIsVerifying] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [serialPort, setSerialPort] = useState<any>(null);
  const [manualIpInput, setManualIpInput] = useState("");
  const [quickExprToast, setQuickExprToast] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedFirmware, setCopiedFirmware] = useState(false);

  const isSodabotConnected = connType !== 'none';
  // 연결이 잠시 끊겨도 저장된 IP가 있으면 명령 전송 시 Wi-Fi 자동 재연결을 시도할 수 있다.
  const canReachSodabot = isSodabotConnected || Boolean(sodabotIp);

  // 1. Verify WebSocket Live Ping
  const verifyWifiConnection = async (ipToCheck?: string | null) => {
    const ip = ipToCheck || sodabotIp || localStorage.getItem('sodabot_robot_ip');
    if (!ip) return;
    setIsVerifying(true); setConnectionError(null);
    try {
      await sodabotTransport.connectWifi(ip);
      await sodabotTransport.send('get_status');
      setSodabotIp(ip);
    } catch (error: any) { setConnectionError(error.message); }
    finally { setIsVerifying(false); setConnType(sodabotTransport.type); }
  };

  // 2. Connect via Web Serial (Direct USB Cable)
  const connectSerial = async () => {
    if (!("serial" in navigator)) {
      alert("현재 브라우저는 Web Serial을 지원하지 않습니다. Chrome 최신 버전을 사용해 주세요.");
      return;
    }
    try {
      setIsVerifying(true);
      setConnectionError(null);
      const port = await (navigator as any).serial.requestPort();
      await port.open({ baudRate: 115200 });
      setSerialPort(port);
      void sodabotTransport.attachSerial(port).catch(error => setConnectionError(error.message));
      setConnType('serial');
      setIsVerifying(false);
      setQuickExprToast("USB 시리얼 연결 성공!");
      setTimeout(() => setQuickExprToast(null), 2500);
    } catch (err: any) {
      setIsVerifying(false);
      if (err.name !== "NotFoundError") {
        setConnectionError(`시리얼 연결 실패: ${err.message}`);
      }
    }
  };

  // 3. Send Hardware Command over Active Link (Serial or WebSocket)
  const sendHardwareCommand = async (action: string, value: string, label?: string, extra: Record<string, unknown> = {}) => {
    try {
      await sodabotTransport.send(action, value, extra);
      setConnectionError(null);
      setQuickExprToast(`${label || "명령"} · 소다봇 처리 완료`); setTimeout(() => setQuickExprToast(null), 4000);
    } catch (error: any) {
      setConnectionError(error.message);
      setQuickExprToast(error.message);
      setTimeout(() => setQuickExprToast(null), 5000);
    }
    setConnType(sodabotTransport.type);
  };

  // Global listener for sodabot-send-command
  useEffect(() => {
    const handleCommandEvent = (e: any) => {
      if (e.detail) {
        const { action, value, label, ...extra } = e.detail;
        sendHardwareCommand(action, value, label, extra);
      }
    };
    window.addEventListener("sodabot-send-command", handleCommandEvent);
    return () => {
      window.removeEventListener("sodabot-send-command", handleCommandEvent);
    };
  }, [connType, serialPort, sodabotIp]);

  // 4. Disconnect Sodabot
  const handleDisconnectSodabot = () => {
    if (confirm("소다봇 연결을 해제하시겠습니까?")) {
      sodabotTransport.disconnect();
      setSerialPort(null);
      localStorage.removeItem("sodabot_robot_ip");
      setSodabotIp(null);
      setConnType('none');
      setConnectionError(null);
      window.dispatchEvent(new Event("sodabot-status-changed"));
      setCurrentView('sodabot');
    }
  };

  // 5. Manual IP Direct Connect
  const handleManualIpConnect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualIpInput.trim()) return;
    const ip = manualIpInput.trim();
    setManualIpInput("");
    verifyWifiConnection(ip);
  };

  // Listen for storage / status events
  useEffect(() => {
    const handleStatus = () => {
      const savedIp = localStorage.getItem("sodabot_robot_ip");
      setSodabotIp(savedIp);
      setConnType(sodabotTransport.type);
    };
    window.addEventListener("sodabot-status-changed", handleStatus);
    window.addEventListener("storage", handleStatus);
    handleStatus();
    return () => {
      window.removeEventListener("sodabot-status-changed", handleStatus);
      window.removeEventListener("storage", handleStatus);
    };
  }, [serialPort]);

  // ----------------------------------------------------
  // 소다봇 미확인 메시지 도착 상태 주기적 체크 및 알림 연동
  // ----------------------------------------------------
  const lastUnreadCountRef = useRef<number>(0);
  const [unreadFriendMessages, setUnreadFriendMessages] = useState<number>(0);
  const lastNotifyTimeRef = useRef<number>(0);

  useEffect(() => {
    if (!token) return;

    const checkUnreadMessages = async () => {
      try {
        const res = await fetch('/api/friends/notifications/count', {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) return;
        const data = await res.json();
        const unreadCount: number = data.unreadMessagesCount || 0;
        setUnreadFriendMessages(unreadCount);

        const isRobotActive = sodabotTransport.type !== 'none' || Boolean(localStorage.getItem('sodabot_robot_ip'));
        const now = Date.now();

        // 1. 미확인 메시지가 있을 때: 소다봇 화면에 도착 표시를 유지 (펌웨어 10초 타임아웃 방지를 위해 6초마다 갱신)
        if (unreadCount > 0) {
          const isNewArrival = unreadCount !== lastUnreadCountRef.current;
          const shouldRefreshDisplay = (now - lastNotifyTimeRef.current) >= 6000;

          if (isRobotActive && (isNewArrival || shouldRefreshDisplay)) {
            lastNotifyTimeRef.current = now;
            try {
              // 깔끔한 영문 텍스트로 알림 전송
              const msgText = unreadCount === 1 
                ? 'NEW MESSAGE\n1 UNREAD' 
                : `NEW MESSAGES\n${unreadCount} UNREAD`;
              await sodabotTransport.send('send_message', msgText);
              if (isNewArrival) {
                await sodabotTransport.send('play_sound', 'BEEP').catch(() => {});
              }
            } catch (err) {
              console.warn('소다봇 메시지 알림 전송 실패:', err);
            }
          }
          lastUnreadCountRef.current = unreadCount;
        } 
        // 2. 웹에서 메시지를 모두 확인했을 때 (안 읽은 메시지 0개): 소다봇 알림 화면 해제 -> 기본 평온 표정
        else if (unreadCount === 0 && lastUnreadCountRef.current > 0) {
          lastUnreadCountRef.current = 0;
          lastNotifyTimeRef.current = 0;
          if (isRobotActive) {
            try {
              await sodabotTransport.send('set_expression', 'default');
            } catch (err) {
              console.warn('소다봇 기본 표정 복구 실패:', err);
            }
          }
        }
      } catch {
        // network or auth error
      }
    };

    checkUnreadMessages();
    const interval = setInterval(checkUnreadMessages, 3000);
    return () => clearInterval(interval);
  }, [token]);

  // Settings Panel State
  const [showSettings, setShowSettings] = useState(false);
  const [aiProvider, setAiProvider] = useState("local");
  const [openaiApiKey, setOpenaiApiKey] = useState("");
  const [lmStudioUrl, setLmStudioUrl] = useState("https://granular-kindly-morally.ngrok-free.dev");
  const [modelName, setModelName] = useState("meta-llama-3-8b-instruct");
  const [fallbackMode, setFallbackMode] = useState(true);
  const [hybridModeEnabled, setHybridModeEnabled] = useState(false);
  const [dailyGptQuota, setDailyGptQuota] = useState(30);
  const [lmStudioConnected, setLmStudioConnected] = useState<boolean | null>(null);
  const [testingConnection, setTestingConnection] = useState(false);
  const [testMessage, setTestMessage] = useState("");

  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(1024);
  const [language, setLanguage] = useState("Korean");
  const [systemStatus, setSystemStatus] = useState<{ memoryUsage?: { total: number, free: number }, openaiUsage?: { used: number, limit: number } }>({});

  // Admin Panel State
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [adminChats, setAdminChats] = useState<any[]>([]);
  const [monitoringChatId, setMonitoringChatId] = useState<string | null>(null);
  const [monitoringTab, setMonitoringTab] = useState<"rooms" | "messages">("rooms");
  const [adminSelectedUserId, setAdminSelectedUserId] = useState<string | null>(null);
  const [adminSelectedUserStatsId, setAdminSelectedUserStatsId] = useState<string | null>(null);
  const [adminUserStats, setAdminUserStats] = useState<any>(null);
  const [showGlobalDashboard, setShowGlobalDashboard] = useState(false);
  const [globalStats, setGlobalStats] = useState<any>(null);
  const [newUsername, setNewUsername] = useState("");
  const [newDisplayName, setNewDisplayName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [adminError, setAdminError] = useState("");

  const handleToggleChatPermission = async (userId: string, currentStatus: boolean) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/permission`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ canAccessChat: !currentStatus })
      });
      if (res.ok) {
        fetchAdminUsers();
      }
    } catch (err) {
      console.error("Failed to update permission", err);
    }
  };

  const handleBatchToggleChatPermission = async (canAccessChat: boolean) => {
    try {
      const res = await fetch("/api/admin/users/batch-permission", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ canAccessChat })
      });
      if (res.ok) {
        fetchAdminUsers();
      }
    } catch (err) {
      console.error("Failed to batch update permissions", err);
    }
  };

  const fetchAdminUsers = async () => {
    try {
      const res = await fetch("/api/admin/users", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setAdminUsers(data.users);
      }
    } catch (err) {
      console.error("Failed to load users", err);
    }
  };

  const fetchGlobalStats = async () => {
    try {
      const res = await fetch('/api/admin/stats/all', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setGlobalStats(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchUserStats = async (userId: string) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/stats`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) {
        setAdminUserStats(data);
        setAdminSelectedUserStatsId(userId);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAdminChats = async () => {
    try {
      const res = await fetch("/api/admin/chats", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) setAdminChats(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (showAdminPanel) {
      fetchAdminUsers();
      fetchAdminChats();
    }
  }, [showAdminPanel]);

  // 5초마다 실시간 대화 피드 갱신
  useEffect(() => {
    let interval: any;
    if (user?.username === "admin") {
      fetchAdminChats(); // 최초 1회 실행
      fetchGlobalStats(); // 대시보드 통계 최초 1회 실행
      interval = setInterval(() => {
        fetchAdminChats();
        fetchGlobalStats();
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [user]);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError("");
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ username: newUsername, displayName: newDisplayName, password: newPassword })
      });
      const data = await res.json();
      if (res.ok) {
        setNewUsername("");
        setNewDisplayName("");
        setNewPassword("");
        fetchAdminUsers();
      } else {
        setAdminError(data.error);
      }
    } catch (err) {
      setAdminError("생성 실패");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm("정말 이 유저를 삭제하시겠습니까?")) return;
    try {
      await fetch(`/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchAdminUsers();
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdatePersona = async (userId: string, newPersona: string) => {
    try {
      await fetch(`/api/admin/users/${userId}/persona`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ persona: newPersona })
      });
      fetchAdminUsers();
      alert("페르소나가 업데이트 되었습니다!");
    } catch (err) {
      console.error(err);
      alert("페르소나 업데이트 실패");
    }
  };

  const handleGenerateApiKey = async (userId: string) => {
    if (!window.confirm("기존 API 키가 있다면 무효화됩니다. 새로 발급하시겠습니까?")) return;
    try {
      await fetch(`/api/admin/users/${userId}/apikey`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchAdminUsers();
    } catch (err) {
      console.error(err);
    }
  };


  const chatEndRef = useRef<HTMLDivElement>(null);
  // 폴링 응답이 대화 초기화 결과를 덮어쓰지 못하도록 진행 중 요청과 세대를 추적한다.
  const chatFetchAbortRef = useRef<AbortController | null>(null);
  const chatFetchGenerationRef = useRef(0);
  const isClearingChatRef = useRef(false);
  const INACTIVITY_TIMEOUT_MS = 30 * 60 * 1000; // 30분 무동작 시 세션 아웃
  const lastActivityRef = useRef<number>(
    parseInt(localStorage.getItem("soda_last_activity") || String(Date.now()), 10)
  );

  // 1. Verify session on mount & Inactivity tracking
  useEffect(() => {
    if (!token) return;

    // 마운트 시 저장된 마지막 활동 시간 체크
    const savedLastActivity = parseInt(localStorage.getItem("soda_last_activity") || "0", 10);
    if (savedLastActivity && Date.now() - savedLastActivity > INACTIVITY_TIMEOUT_MS) {
      alert("30분 동안 활동이 없어 세션이 만료되었습니다. 다시 로그인해 주세요.");
      handleLogout();
      return;
    }

    verifySession(token);

    // 사용자 인터랙션 감지 (마우스, 키보드, 스크롤, 터치, 클릭)
    let lastUpdate = 0;
    const recordUserActivity = () => {
      const now = Date.now();
      lastActivityRef.current = now;
      // 3초 단위로 localStorage 갱신 (과도한 I/O 방지)
      if (now - lastUpdate > 3000) {
        lastUpdate = now;
        localStorage.setItem("soda_last_activity", String(now));
      }
    };

    const activityEvents = ["mousedown", "mousemove", "keydown", "scroll", "touchstart", "click"];
    activityEvents.forEach(evt => window.addEventListener(evt, recordUserActivity, { passive: true }));

    // 10초 주기로 30분 무동작 검사 & 실시간 학생 권한 동기화
    const interval = setInterval(() => {
      const now = Date.now();
      const lastAct = lastActivityRef.current || parseInt(localStorage.getItem("soda_last_activity") || "0", 10);
      if (lastAct && now - lastAct > INACTIVITY_TIMEOUT_MS) {
        clearInterval(interval);
        alert("30분 동안 활동이 없어 세션이 만료되었습니다. 다시 로그인해 주세요.");
        handleLogout();
        return;
      }
      verifySession(token);
    }, 5000);

    return () => {
      activityEvents.forEach(evt => window.removeEventListener(evt, recordUserActivity));
      clearInterval(interval);
    };
  }, [token]);

  // 2. Fetch data once logged in
  useEffect(() => {
    if (user) {
      if (user.username === "admin") {
        setMainNavTab("chat");
      } else if (!user.canAccessChat) {
        setMainNavTab("dev");
      }
      fetchChats();
      fetchLMStudioConfig();
    }
  }, [user?.id]);

  // 3. Auto-scroll chat history to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chats, activeChatId, sending]);

  // 4. 음성 대화 실시간 폴링 및 소다봇 이벤트 리스너 (최상단 훅으로 배치)
  useEffect(() => {
    if (!token || !user) return;
    const interval = setInterval(() => {
      fetchChats();
    }, 1500);

    const handleVoiceCompleted = () => {
      fetchChats();
    };
    const handleSettingsUpdated = (e?: any) => {
      setSettingsVersion(v => v + 1);
      if (e?.detail) {
        setUser(prev => prev ? { ...prev, friendSettings: e.detail } : null);
      }
      if (token) verifySession(token);
    };

    window.addEventListener('sodabot-voice-chat', handleVoiceCompleted);
    window.addEventListener('sodabot-settings-updated', handleSettingsUpdated as EventListener);

    return () => {
      clearInterval(interval);
      chatFetchAbortRef.current?.abort();
      window.removeEventListener('sodabot-voice-chat', handleVoiceCompleted);
      window.removeEventListener('sodabot-settings-updated', handleSettingsUpdated);
    };
  }, [token, user?.id]);

  const handleClearChat = async () => {
    if (isClearingChatRef.current || !user) return;

    const currentChat = chats.find(c => c.id === activeChatId) || (chats.length > 0 ? chats[0] : undefined);
    const currentChatId = currentChat?.id;
    const allChatIds = chats.map(c => c.id);

    // 초기화 전에 시작된 GET 응답은 abort를 지원하지 않는 환경에서도 세대 검사로 무시된다.
    isClearingChatRef.current = true;
    setClearingChat(true);
    chatFetchGenerationRef.current += 1;
    chatFetchAbortRef.current?.abort();
    chatFetchAbortRef.current = null;

    // 1. 즉시 로컬 화면을 깨끗한 1개의 대화방으로 리셋 (즉각적 반응)
    const tempChatId = "chat-" + Date.now();
    const emptyChat: ChatRoom = {
      id: tempChatId,
      userId: user.id,
      title: "새로운 대화 ✨",
      createdAt: new Date().toISOString(),
      messages: []
    };
    setChats([emptyChat]);
    setActiveChatId(tempChatId);

    // 2. 백엔드 동기화 (서버 대화 전체 리셋 및 새 대화방 생성)
    try {
      const res = await fetch("/api/chats/clear-all", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ currentChatId, chatIds: allChatIds })
      });
      const data = await res.json();
      if (!res.ok || !data.chat) {
        throw new Error(data.error || "대화 초기화에 실패했습니다.");
      }

      setChats([data.chat]);
      setActiveChatId(data.chat.id);
    } catch (err) {
      console.error("Failed to clear chat on backend", err);
      alert("대화를 초기화하지 못했습니다. 잠시 후 다시 시도해 주세요.");
      // 낙관적으로 비운 화면을 서버의 실제 상태로 되돌린다.
      isClearingChatRef.current = false;
      setClearingChat(false);
      await fetchChats();
      return;
    } finally {
      if (isClearingChatRef.current) {
        isClearingChatRef.current = false;
        setClearingChat(false);
      }
    }
  };

  const verifySession = async (sessionToken: string) => {
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${sessionToken}` }
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setUser(data.user);
      } else {
        handleLogout();
      }
    } catch (err) {
      console.error("Session verification failed", err);
      handleLogout();
    }
  };

  const fetchChats = async () => {
    // 느린 네트워크에서도 1.5초마다 이전 요청을 끊지 않도록 조회는 하나만 유지한다.
    if (isClearingChatRef.current || chatFetchAbortRef.current) return;

    const requestGeneration = chatFetchGenerationRef.current;
    const controller = new AbortController();
    chatFetchAbortRef.current = controller;

    try {
      const res = await fetch("/api/chats", {
        headers: { Authorization: `Bearer ${token}` },
        signal: controller.signal
      });
      const data = await res.json();

      // 초기화 도중이거나 초기화 전에 출발한 요청이면 절대 화면 상태를 갱신하지 않는다.
      if (
        controller.signal.aborted ||
        isClearingChatRef.current ||
        requestGeneration !== chatFetchGenerationRef.current
      ) return;

      if (res.ok && Array.isArray(data)) {
        if (data.length === 0) return;
        const sortedChats = [...data].sort((a: ChatRoom, b: ChatRoom) => {
          const timeA = a.messages && a.messages.length > 0
            ? new Date(a.messages[a.messages.length - 1].timestamp).getTime()
            : new Date(a.createdAt).getTime();
          const timeB = b.messages && b.messages.length > 0
            ? new Date(b.messages[b.messages.length - 1].timestamp).getTime()
            : new Date(b.createdAt).getTime();
          return timeB - timeA;
        });
        setChats(sortedChats);
        setActiveChatId(prev => {
          if (!prev) return sortedChats[0].id;
          const exists = sortedChats.some(c => c.id === prev);
          return exists ? prev : sortedChats[0].id;
        });
      }
    } catch (err: any) {
      if (err?.name === "AbortError") return;
      console.error("Failed to fetch chats", err);
    } finally {
      if (chatFetchAbortRef.current === controller) {
        chatFetchAbortRef.current = null;
      }
    }
  };

  const fetchLMStudioConfig = async () => {
    try {
      const res = await fetch("/api/lmstudio/config");
      const data = await res.json();
      if (res.ok) {
        if (data.aiProvider) setAiProvider(data.aiProvider || "local");
        setOpenaiApiKey(data.openaiApiKey || "");
        if (data.lmStudioUrl) setLmStudioUrl(data.lmStudioUrl);
        if (data.modelName) setModelName(data.modelName);
        setFallbackMode(data.fallbackMode);
        if (data.hybridModeEnabled !== undefined) setHybridModeEnabled(data.hybridModeEnabled);
        if (data.dailyGptQuota !== undefined) setDailyGptQuota(data.dailyGptQuota);
        if (data.temperature !== undefined) setTemperature(data.temperature);
        if (data.maxTokens !== undefined) setMaxTokens(data.maxTokens);
        if (data.language !== undefined) setLanguage(data.language);
        checkConnection(data.lmStudioUrl);
      }
    } catch (err) {
      console.error("Failed to load LM Studio settings", err);
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (user) {
      const fetchStatus = async () => {
        try {
          const res = await fetch("/api/system/status");
          if (res.ok) {
            const data = await res.json();
            setSystemStatus(data);
          }
        } catch (err) {
          // ignore
        }
      };
      fetchStatus();
      interval = setInterval(fetchStatus, 3000);
    }
    return () => clearInterval(interval);
  }, [user]);

  const checkConnection = async (urlToCheck?: string) => {
    const url = urlToCheck || lmStudioUrl;
    try {
      const res = await fetch("/api/lmstudio/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lmStudioUrl: url })
      });
      const data = await res.json();
      setLmStudioConnected(data.connected);
      return data;
    } catch (err) {
      setLmStudioConnected(false);
      return { connected: false, message: "연결 오류가 발생했습니다." };
    }
  };

  const handleCreateNewChat = () => {
    setActiveChatId(null);
  };

  const handleDeleteChat = async (e: React.MouseEvent, chatId: string) => {
    e.stopPropagation(); // prevent setting active
    if (!confirm("이 대화방을 완전히 삭제할까요?")) return;

    try {
      const res = await fetch(`/api/chats/${chatId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setChats(prev => prev.filter(c => c.id !== chatId));
        if (activeChatId === chatId) {
          const remaining = chats.filter(c => c.id !== chatId);
          setActiveChatId(remaining.length > 0 ? remaining[0].id : null);
        }
      }
    } catch (err) {
      console.error("Failed to delete chat", err);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent, presetText?: string) => {
    if (e) e.preventDefault();
    const textToSend = presetText || inputText;
    if (!textToSend.trim() || sending) return;

    let targetChatId = activeChatId;

    // Create a chat automatically if none is selected or active
    if (!targetChatId) {
      try {
        const res = await fetch("/api/chats", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ title: textToSend.substring(0, 16) })
        });
        const data = await res.json();
        if (res.ok) {
          setChats(prev => [data, ...prev]);
          targetChatId = data.id;
          setActiveChatId(data.id);
        } else {
          return;
        }
      } catch (err) {
        console.error("Auto chat creation failed", err);
        return;
      }
    }

    setSending(true);
    if (!presetText) setInputText("");

    // 1. Create and render User Message locally
    const userMsg: Message = {
      id: "msg-" + Date.now() + "-user",
      sender: "user",
      text: textToSend,
      timestamp: new Date().toISOString(),
      source: "web"
    };

    let updatedChats = chats;
    setChats(prev => {
      updatedChats = prev.map(c => {
        if (c.id === targetChatId) return { ...c, messages: [...c.messages, userMsg] };
        return c;
      });
      return updatedChats;
    });

    // Sync User Message to backend
    try {
      await fetch(`/api/chats/${targetChatId}/sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ messages: [userMsg] })
      });
    } catch (err) {
      console.error("Failed to sync user message", err);
    }

    const assistantMsgId = "msg-" + Date.now() + "-assistant";
    let assistantMsgText = "";
    let usedModelName = "";

    setChats(prev => prev.map(c => {
      if (c.id === targetChatId) {
        return {
          ...c,
          messages: [...c.messages, { id: assistantMsgId, sender: "assistant", text: "", timestamp: new Date().toISOString(), source: "web" }]
        };
      }
      return c;
    }));

    try {
      const currentChat = chats.find(c => c.id === targetChatId);
      const previousMessages = currentChat ? currentChat.messages : [];
      const cleanMessages = previousMessages.filter(m => !m.text.includes("로컬 엔진이 잠시 쉬고 있어"));
      const windowedMessages = [...cleanMessages, userMsg].slice(-20);

      const conversationHistory = windowedMessages.map(m => ({
        role: m.sender === "user" ? "user" : "assistant",
        content: m.text
      }));

      // Build Shared Friend Persona identical to Hardware & Settings
      const { persona, profile, memories } = getLatestFriendSettings();

      // 웹에서 실제 사용 중인 최신 로컬 프로필을 서버에도 먼저 저장해
      // 다음 소다봇 음성 요청이 완전히 같은 사용자/페르소나를 사용하게 한다.
      try {
        const settingsRes = await fetch("/api/user/friend-settings", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ persona, profile, memories })
        });
        if (!settingsRes.ok) {
          console.warn("Failed to sync web friend settings:", await settingsRes.text());
        }
      } catch (settingsError) {
        console.warn("Failed to sync web friend settings", settingsError);
      }

      const botName = persona.name || "소다봇";
      const studentName = profile.userName || user?.displayName || "친구";
      const userCallSign = studentName;
      const roleName = persona.role || "공부친구";
      const toneName = persona.tone || "친근한 친구말";
      const personalityName = persona.personality || "친절함";
      const schoolName = profile.school || "미설정";
      const interestsList = Array.isArray(profile.interests) ? profile.interests.join(", ") : (profile.interests || "미설정");
      const goalText = profile.goal || "미설정";

      const studentWithJosa = getJosa(studentName, '은는');
      const botWithJosa = getJosa(botName, '이야');
      const interestsWithJosa = getJosa(interestsList, '을를');

      let sodabotPersona = `미설정된 개인정보는 추측하거나 만들어내지 마세요. 이름은 사용자를 부르는 이름으로도 사용합니다.\n당신은 학생 '${studentName}'의 친한 AI 로봇 '${botName}'입니다.

[1. 대화하는 상대방(사용자) 정보 - 매우 중요]
- 이름: ${studentName} (호칭: ${userCallSign})
- 학교: ${schoolName}
- 취미 및 관심사: ${interestsList}
- 장래희망: ${goalText}
★ 사용자가 "나는 누구야?", "나는 누군데?", "내 이름이 뭐야?", "내가 누구지?", "내 취미가 뭐야?", "내가 좋아하는 게 뭐야?"라고 질문하면:
  -> 질문자는 바로 '${studentName}'입니다! 절대로 사용자보고 소다봇이나 로봇이라고 하지 마세요!
  -> 저장된 정보만 사용하고, 미설정인 학교나 취미는 아직 모른다고 말한 뒤 물어보세요.

[2. 답변하는 당신(AI 반려 로봇) 정보]
- 이름: ${botName}
- 역할: ${roleName}
- 성격: ${personalityName}
- 말투: ${friendToneInstruction(toneName)}
★ 사용자가 "너는 누구야?", "너는 누군데?", "자기소개해줘"라고 질문하면:
  -> 당신은 AI 로봇 '${botName}'입니다.
  -> 답변: "안녕 ${userCallSign}! 나는 너의 ${roleName} ${botWithJosa}! 오늘 어떤 이야기를 해볼까?"`;

      if (memories.length > 0) {
        sodabotPersona += `\n\n[3. 우리가 함께 나눈 기억들]:\n` + memories.map((m: any, idx: number) => `  ${idx + 1}. ${m.text || m.content}`).join("\n");
      }

      const res = await fetch(`/api/lmstudio/stream`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          chatId: targetChatId,
          model: modelName,
          messages: [
            { role: "system", content: sodabotPersona },
            ...conversationHistory
          ],
          temperature: temperature,
          max_tokens: maxTokens,
          stream: true
        })
      });

      console.log("LM Studio HTTP status:", res.status);
      if (!res.ok) {
        const errText = await res.text();
        console.error("LM Studio error response:", errText);
        throw new Error(errText || `LM Studio HTTP 에러: ${res.status}`);
      }

      if (!res.body) throw new Error("ReadableStream not supported in this browser.");

      const reader = res.body.getReader();
      const decoder = new TextDecoder("utf-8");
      let done = false;
      let buffer = "";

      while (!done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || ""; // Keep the last incomplete line in buffer

          for (let line of lines) {
            line = line.trim();
            if (line.startsWith("data:") && !line.includes("[DONE]")) {
              try {
                const payload = line.replace(/^data:\s*/, "");
                const parsed = JSON.parse(payload);
                if (parsed.model) usedModelName = parsed.model;
                const tokenContent = parsed.choices?.[0]?.delta?.content || "";

                if (tokenContent) {
                  assistantMsgText += tokenContent;
                  console.log("Received token:", tokenContent, "Total text so far:", assistantMsgText);

                  setChats(prev => prev.map(c => {
                    if (c.id === targetChatId) {
                      return {
                        ...c,
                        messages: c.messages.map(m =>
                          m.id === assistantMsgId ? { ...m, text: assistantMsgText, modelUsed: usedModelName || m.modelUsed } : m
                        )
                      };
                    }
                    return c;
                  }));
                }
              } catch (e) {
                console.error("Stream parse error:", e, "Line:", line);
              }
            }
          }
        }
      }

      if (!assistantMsgText.trim()) throw new Error("AI가 빈 응답을 보냈습니다. 다시 질문해주세요.");
      console.log("Stream completely finished!");

    } catch (err: any) {
      console.warn("Client-side LM Studio connect error:", err);
      const errDetails = err.message || err.toString();
      assistantMsgText = (assistantMsgText ? assistantMsgText + "\n\n" : "") + (err.name === "TimeoutError" || err.name === "AbortError" ? "응답 대기 시간이 초과됐습니다. 다시 질문해주세요." : "응답을 받지 못했습니다. " + errDetails);
      setChats(prev => prev.map(c => {
        if (c.id === targetChatId) {
          return {
            ...c,
            messages: c.messages.map(m => m.id === assistantMsgId ? { ...m, text: assistantMsgText } : m)
          };
        }
        return c;
      }));
    } finally {
      setSending(false);
      // Sync finalized Assistant Message to backend
      const assistantMsgFinal: Message = {
        id: assistantMsgId,
        sender: "assistant",
        text: assistantMsgText,
        timestamp: new Date().toISOString(),
        modelUsed: usedModelName || "Unknown Model"
      };

      try {
        await fetch(`/api/chats/${targetChatId}/sync`, {
          method: "POST",
          signal: AbortSignal.timeout(5000),
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ messages: [assistantMsgFinal] })
        });
      } catch (err) {
        console.error("Failed to sync assistant message", err);
      }

      setSending(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/lmstudio/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          aiProvider,
          openaiApiKey,
          lmStudioUrl,
          modelName,
          fallbackMode,
          hybridModeEnabled,
          dailyGptQuota
        })
      });
      if (res.ok) {
        setShowSettings(false);
        checkConnection(lmStudioUrl);
      }
    } catch (err) {
      console.error("Failed to save settings", err);
    }
  };

  const handleToggleProvider = async () => {
    const newProvider = aiProvider === "local" ? "openai" : "local";
    setAiProvider(newProvider); // Optimistic UI update
    try {
      await fetch("/api/lmstudio/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aiProvider: newProvider })
      });
    } catch (err) {
      console.error("Failed to toggle provider", err);
    }
  };

  const handleTestSettingsConnection = async () => {
    setTestingConnection(true);
    setTestMessage("");
    const res = await checkConnection(lmStudioUrl);
    setTestMessage(res.message);
    setTestingConnection(false);
  };

  const handleLoginSuccess = (sessionId: string, loggedInUser: { id: string; username: string; displayName: string }) => {
    localStorage.setItem("authSessionId", sessionId);
    localStorage.setItem("soda_last_activity", String(Date.now()));
    lastActivityRef.current = Date.now();
    setToken(sessionId);
    setUser(loggedInUser);
    setCurrentView('welcome');
    
    // Check if new user has a saved robot IP
    const userKey = loggedInUser.id || loggedInUser.username;
    const userSavedIp = localStorage.getItem(`sodabot_${userKey}_robot_ip`);
    if (!userSavedIp) {
      sodabotTransport.disconnect();
      localStorage.removeItem("sodabot_robot_ip");
      localStorage.removeItem("sodabot_connected");
      setSodabotIp(null);
      setConnType('none');
    } else {
      setSodabotIp(userSavedIp);
    }
    window.dispatchEvent(new Event("sodabot-status-changed"));
  };

  const handleLogout = async () => {
    if (token) {
      try {
        await fetch("/api/auth/logout", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (err) {
        console.error("Logout request failed", err);
      }
    }
    sodabotTransport.disconnect();
    localStorage.removeItem("authSessionId");
    localStorage.removeItem("soda_last_activity");
    localStorage.removeItem("sodabot_robot_ip");
    localStorage.removeItem("sodabot_connected");
    localStorage.removeItem("sodabot_custom_name");
    localStorage.removeItem("sodabot_device_name");
    localStorage.removeItem("sodabot_wifi_ssid");
    localStorage.removeItem("sodabot_wifi_password");
    setToken(null);
    setUser(null);
    setChats([]);
    setActiveChatId(null);
    setSodabotIp(null);
    setConnType('none');
    window.dispatchEvent(new Event("sodabot-status-changed"));
  };

  if (!user) {
    return <AuthScreen onLoginSuccess={handleLoginSuccess} />;
  }

  const activeChat = chats.find(c => c.id === activeChatId) || (chats.length > 0 ? chats[0] : undefined);

  // Dynamic Action Cards following the 5 Priorities
  const getDynamicActionCards = () => {
    const cards: Array<{
      title: string;
      desc: string;
      action_type: string;
      onClick: () => void;
    }> = [];

    const latest = getLatestFriendSettings();
    const botName = latest.persona.name || "루미";

    // 1순위: 즉시 확인해야 하는 활동 (읽지 않은 친구 메시지 / 새 요청)
    if (unreadFriendMessages > 0) {
      cards.push({
        title: `친구 메시지 ${unreadFriendMessages}개 확인 💬`,
        desc: "새로 도착한 친구 메시지를 확인하고 소다봇으로 들어보세요.",
        action_type: "open_friend_chat",
        onClick: () => {
          if (isMobile) setMobileTab('friends');
          else setCurrentView('friends');
        }
      });
    }

    // 2순위: 최근 AI 대화 이어가기
    if (activeChat && activeChat.messages.length > 0) {
      const lastMsg = activeChat.messages[activeChat.messages.length - 1];
      const previewText = lastMsg.text.length > 18 ? lastMsg.text.slice(0, 18) + '...' : lastMsg.text;
      cards.push({
        title: `${botName}와 이어서 대화하기 🤖`,
        desc: `"${previewText}" 대화를 이어서 진행해보세요.`,
        action_type: "continue_ai_chat",
        onClick: () => {
          handleSendMessage(undefined, "지난번에 이야기하던 내용에 대해 조금 더 자세히 알려줘!");
        }
      });
    } else {
      cards.push({
        title: `${botName}에게 질문하기 💡`,
        desc: "오늘 배운 아두이노 코드나 회로에 대해 자유롭게 물어보세요.",
        action_type: "start_ai_chat",
        onClick: () => {
          handleSendMessage(undefined, `안녕 ${botName}! 오늘 배울 수 있는 재미있는 소다봇 코딩 팁 하나만 알려줘.`);
        }
      });
    }

    // 3순위: 소다봇 하드웨어 활용 (표정 바꾸기 / 소다봇 제어)
    if (isSodabotConnected || sodabotIp) {
      cards.push({
        title: "소다봇 표정 바꾸기 🎮",
        desc: "실물 소다봇의 LCD 눈동자 표정을 원터치로 바꿔보세요.",
        action_type: "open_robot_control",
        onClick: () => {
          if (isMobile) setMobileTab('control');
          else setCurrentView('settings');
        }
      });
    } else {
      cards.push({
        title: "소다봇 로봇 연동하기 🔗",
        desc: "블루투스나 Wi-Fi로 내 책상의 실물 소다봇과 연결해보세요.",
        action_type: "open_robot_connect",
        onClick: () => {
          if (isMobile) setMobileTab('control');
          else setCurrentView('sodabot');
        }
      });
    }

    // 4순위: 우리반 그룹 대화방
    if (cards.length < 3) {
      cards.push({
        title: "우리반 그룹 대화방 👥",
        desc: "반 친구들과 함께 다자간 그룹 채팅을 시작해보세요.",
        action_type: "open_group_chat",
        onClick: () => {
          if (isMobile) setMobileTab('friends');
          else setCurrentView('friends');
        }
      });
    }

    // 5순위: 소다봇 친구설정 & 기억 관리
    if (cards.length < 3) {
      cards.push({
        title: "소다봇 친구설정 마무리 🧠",
        desc: "나의 성격, 관심사, 목표 3가지를 소다봇에게 가르쳐주세요.",
        action_type: "open_friend_settings",
        onClick: () => {
          if (isMobile) setMobileTab('settings');
          else setCurrentView('sodabot_builder');
        }
      });
    }

    return cards.slice(0, 3);
  };

  const memTotalGB = systemStatus?.memoryUsage ? (systemStatus.memoryUsage.total / 1024 / 1024 / 1024).toFixed(1) : "8.0";
  const memFreeGB = systemStatus?.memoryUsage ? (systemStatus.memoryUsage.free / 1024 / 1024 / 1024).toFixed(1) : "1.8";
  const memUsedGB = (parseFloat(memTotalGB) - parseFloat(memFreeGB)).toFixed(1);
  const memPercent = Math.min(100, Math.max(0, (parseFloat(memUsedGB) / parseFloat(memTotalGB)) * 100));

  const openaiUsed = systemStatus?.openaiUsage?.used || 3240;
  const openaiLimit = systemStatus?.openaiUsage?.limit || 10000;
  const openaiPercent = Math.min(100, Math.max(0, (openaiUsed / openaiLimit) * 100));

  // ===== RESPONSIVE MOBILE APP LAYOUT (<768px) =====
  if (isMobile) {
    const latestSettings = getLatestFriendSettings();
    const botName = latestSettings.persona.name || "루미";
    const studentName = latestSettings.profile.userName || user.displayName;
    const roleName = latestSettings.persona.role || "공부친구";

    return (
      <div className="flex flex-col h-[100dvh] w-full bg-[#F8FAFC] overflow-hidden select-none relative font-sans text-[#1D1D1F]">
        {/* PWA Floating Install Banner */}
        <PwaInstallBanner />

        {/* Global Hardware Action Toast */}
        {quickExprToast && (
          <div className="fixed top-3 left-4 right-4 z-50 bg-slate-900/95 backdrop-blur-md text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="truncate">{quickExprToast}</span>
          </div>
        )}

        {/* Mobile Views Container */}
        <div className="flex-1 flex flex-col overflow-hidden relative">
          {mobileTab === 'home' && (
            <MobileHomeScreen
              currentUser={user}
              isSodabotConnected={isSodabotConnected}
              robotName={botName}
              sodabotIp={sodabotIp}
              onNavigateTab={(tab, extra) => {
                setMobileTab(tab);
                if (tab === 'chat') setCurrentView('chat');
                if (tab === 'friends') setCurrentView('friends');
                if (tab === 'settings') setCurrentView('sodabot_builder');
              }}
              onLogout={handleLogout}
              onQuickReconnect={() => verifyWifiConnection()}
              isVerifying={isVerifying}
            />
          )}

          {mobileTab === 'chat' && (
            <div className="flex-1 flex flex-col h-full overflow-hidden bg-white">
              {/* Mobile Chat Header */}
              <header className="py-3 px-4 bg-white border-b border-slate-200/80 flex items-center justify-between shrink-0 shadow-2xs">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs shrink-0">
                    🤖
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-xs font-extrabold text-[#0F172A] truncate flex items-center gap-1.5">
                      <span>{botName}</span>
                      <span className="text-[10px] font-normal text-slate-400">· {roleName}</span>
                    </h2>
                    <div className="flex items-center gap-1 mt-0.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${isSodabotConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                      <span className="text-[9px] text-slate-500 font-medium">
                        {isSodabotConnected ? '실물 소다봇 연동됨' : '웹 단독 대화'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleClearChat}
                    disabled={clearingChat}
                    className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all cursor-pointer"
                    title="대화 초기화"
                  >
                    <RotateCcw className={`w-4 h-4 ${clearingChat ? 'animate-spin text-rose-600' : ''}`} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setMobileTab('settings')}
                    className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all cursor-pointer"
                    title="친구 설정"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </header>

              {/* Conversation Stream */}
              <div className="flex-1 overflow-y-auto p-4 bg-[#FAF9F6]/60 relative space-y-4">
                {(!activeChat || activeChat.messages.length === 0) ? (
                  <div className="py-8 text-center space-y-4">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto shadow-2xs">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-sm font-extrabold text-[#0F172A]">
                        안녕하세요, {studentName}님!
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        웹 채팅과 실물 소다봇 음성 대화가<br />하나의 친구 기억으로 연결되어 있어요.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 gap-2 pt-2 text-left">
                      {getDynamicActionCards().map((card, idx) => (
                        <button
                          key={idx}
                          onClick={card.onClick}
                          className="p-3 bg-white hover:bg-indigo-50/50 border border-slate-200/80 rounded-2xl shadow-2xs text-xs font-semibold text-slate-700 transition-all active:scale-[0.98] cursor-pointer"
                        >
                          <span className="block text-[#0F172A] font-bold text-xs">{card.title}</span>
                          <span className="text-[11px] text-slate-500 font-normal line-clamp-1 mt-0.5">{card.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 pb-4">
                    {activeChat.messages.map((msg) => {
                      const isUser = msg.sender === "user";
                      const isSodabotSource = msg.source === "sodabot";

                      return (
                        <div
                          key={msg.id}
                          className={`flex ${isUser ? "justify-end" : "justify-start"} items-start gap-2.5`}
                        >
                          {!isUser && (
                            <div className="w-7 h-7 rounded-xl bg-white border border-indigo-200 flex items-center justify-center text-indigo-600 shrink-0 shadow-2xs text-xs">
                              🤖
                            </div>
                          )}

                          <div
                            className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                              isUser
                                ? "bg-indigo-600 text-white rounded-tr-xs shadow-2xs"
                                : "bg-white border border-slate-200/80 text-[#1E293B] rounded-tl-xs shadow-2xs space-y-2"
                            }`}
                          >
                            {/* Source Badge for User */}
                            {isUser && (
                              <div className="flex items-center gap-1 mb-1">
                                <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold font-mono ${
                                  isSodabotSource
                                    ? "bg-indigo-900/50 text-indigo-200 border border-indigo-400/40"
                                    : "bg-indigo-700 text-indigo-100"
                                }`}>
                                  {isSodabotSource ? "🎙 SODABOT" : "⌨ WEB"}
                                </span>
                              </div>
                            )}

                            <div className="whitespace-pre-wrap break-words leading-relaxed">
                              {msg.text}
                            </div>

                            {/* Metadata & Speak on Sodabot Button */}
                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono border-t border-slate-100 pt-1.5 mt-1.5 gap-2">
                              <span>
                                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>

                              {SHOW_SODABOT_VOICE_PLAYBACK && !isUser && (
                                <button
                                  type="button"
                                  disabled={!canReachSodabot || speakingMessageId !== null}
                                  onClick={async () => {
                                    if (!canReachSodabot) return;
                                    setSpeakingMessageId(msg.id);
                                    setQuickExprToast("🔊 소다봇 음성 재생 중...");
                                    try {
                                      await sendHardwareCommand('speak', msg.text, '음성 재생');
                                    } finally {
                                      setSpeakingMessageId(null);
                                    }
                                  }}
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold rounded-lg border transition-all ${
                                    canReachSodabot && speakingMessageId === null
                                      ? "text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border-indigo-200 cursor-pointer"
                                      : "text-slate-400 bg-slate-50 border-slate-200 opacity-60"
                                  }`}
                                >
                                  <span>{speakingMessageId === msg.id ? "⏳ 재생 중..." : "🔊 소다봇으로 말하기"}</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {sending && (
                      <div className="flex justify-start items-start gap-2.5">
                        <div className="w-7 h-7 rounded-xl bg-white border border-indigo-200 flex items-center justify-center text-indigo-600 shrink-0 text-xs shadow-2xs">
                          🤖
                        </div>
                        <div className="bg-white border border-slate-200/80 rounded-2xl p-3 text-xs text-slate-500 font-mono flex items-center gap-2 shadow-2xs">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                          <span>소다봇이 생각하고 있어요...</span>
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                )}
              </div>

              {/* Chat Input Footer */}
              <footer className="p-3 bg-white border-t border-slate-200/80 pb-20">
                <form onSubmit={handleSendMessage} onKeyDown={preventImeSubmit} className="relative flex items-center">
                  <input
                    type="text"
                    required
                    disabled={sending}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="소다봇에게 물어보세요..."
                    className="w-full pl-4 pr-11 py-3 bg-[#F8FAFC] border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-2xl text-xs font-sans outline-none transition-all placeholder:text-slate-400"
                  />
                  <button
                    type="submit"
                    disabled={!inputText.trim() || sending}
                    className="absolute right-1.5 p-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl transition-all cursor-pointer shadow-xs"
                    title="전송"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </footer>
            </div>
          )}

          {mobileTab === 'friends' && (
            <div className="flex-1 flex flex-col h-full overflow-hidden pb-16">
              <SodabotFriendsScreen
                currentUser={user}
                token={token}
                isSodabotConnected={isSodabotConnected}
                onBackToChat={() => setMobileTab('home')}
              />
            </div>
          )}

          {mobileTab === 'control' && (
            <MobileControlScreen
              currentUser={user}
              isSodabotConnected={isSodabotConnected}
              robotName={botName}
              sodabotIp={sodabotIp}
              onVerifyConnection={verifyWifiConnection}
              isVerifying={isVerifying}
            />
          )}

          {mobileTab === 'settings' && (
            <div className="flex-1 flex flex-col h-full overflow-hidden pb-16">
              <SodabotFriendSettingsScreen currentUser={user} />
            </div>
          )}
        </div>

        {/* Fixed Mobile Bottom Tab Bar */}
        <MobileBottomTabBar
          currentTab={mobileTab}
          onSelectTab={(tab) => {
            setMobileTab(tab);
            if (tab === 'chat') setCurrentView('chat');
            if (tab === 'friends') setCurrentView('friends');
            if (tab === 'settings') setCurrentView('sodabot_builder');
          }}
          unreadFriendsCount={unreadFriendMessages}
        />
      </div>
    );
  }

  // ===== ADMIN CUSTOM LAYOUT =====
  if (user?.username === "admin") {
    return (
      <div className="flex h-screen bg-[#FAF9F6] text-[#1D1D1F] font-sans antialiased overflow-hidden">
        {/* 1. Admin Left Sidebar */}
        <aside className="w-64 border-r border-[#EAE6DF] bg-[#FAF9F6] flex flex-col shrink-0 select-none">
          <div className="p-5 pb-2">
            <h1 className="text-xl font-bold tracking-tight text-[#1D1D1F] flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs">S</span>
              Admin Console
            </h1>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
            <div className="space-y-1">
              <div className="text-[10px] font-bold text-[#86868B] px-2 mb-2 uppercase tracking-wider">시스템 관리</div>
              <button onClick={() => { setMainNavTab("chat"); fetchGlobalStats(); setShowGlobalDashboard(true); }} className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 flex items-center gap-2 transition-colors cursor-pointer">
                <Activity className="w-4 h-4" /> 통합 모니터링
              </button>
              <button onClick={() => setShowAdminPanel(true)} className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-indigo-700 hover:bg-indigo-50 border border-transparent hover:border-indigo-200 flex items-center gap-2 transition-colors cursor-pointer">
                <Users className="w-4 h-4" /> 유저 및 권한 관리
              </button>
              <button onClick={() => setShowCourseManager(true)} className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-blue-700 hover:bg-blue-50 border border-transparent hover:border-blue-200 flex items-center gap-2 transition-colors cursor-pointer">
                <FolderCode className="w-4 h-4 text-blue-600" /> 주차별 컨텐츠 관리
              </button>
              <button onClick={() => setShowSettings(true)} className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-[#5C5B57] hover:bg-white border border-transparent hover:border-[#EAE6DF] flex items-center gap-2 transition-colors cursor-pointer">
                <Settings className="w-4 h-4" /> 서버 설정
              </button>
            </div>

            <div className="space-y-1 pt-4 border-t border-[#EAE6DF]">
              <div className="text-[10px] font-bold text-[#86868B] px-2 mb-2 uppercase tracking-wider">개발 & 하드웨어 도구</div>
              <button
                onClick={() => { setMainNavTab("ide"); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-indigo-700 hover:bg-indigo-50 border border-transparent hover:border-indigo-200 flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Zap className="w-4 h-4 text-amber-500" /> Web Arduino IDE
              </button>
              <button
                onClick={() => { setMainNavTab("dev"); }}
                className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-[#5C5B57] hover:bg-white border border-transparent hover:border-[#EAE6DF] flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Library className="w-4 h-4 text-indigo-500" /> 수업 자료실 뷰
              </button>
            </div>

            <div className="space-y-1 pt-4 border-t border-[#EAE6DF]">
              <div className="flex items-center justify-between px-2 mb-2">
                <div className="text-[10px] font-bold text-[#86868B] uppercase tracking-wider">대화 목록</div>
                <button
                  onClick={handleCreateNewChat}
                  className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold transition-colors cursor-pointer"
                >
                  <PlusCircle className="w-3 h-3 inline mr-0.5" />새 대화
                </button>
              </div>
              {chats.length === 0 ? (
                <div className="px-2 py-2 text-[11px] text-[#86868B] text-center">대화 기록이 없습니다.</div>
              ) : (
                [...chats].sort((a, b) => {
                  const timeA = a.messages && a.messages.length > 0 ? new Date(a.messages[a.messages.length - 1].timestamp).getTime() : new Date(a.createdAt).getTime();
                  const timeB = b.messages && b.messages.length > 0 ? new Date(b.messages[b.messages.length - 1].timestamp).getTime() : new Date(b.createdAt).getTime();
                  return timeB - timeA;
                }).map(chat => {
                  const isActive = (activeChatId === chat.id || (!activeChatId && chat.id === chats[0]?.id)) && currentView === 'chat';
                  return (
                    <div
                      key={chat.id}
                      onClick={() => {
                        setActiveChatId(chat.id);
                        setCurrentView('chat');
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between cursor-pointer transition-all ${
                        isActive
                          ? "bg-indigo-50/90 border border-indigo-200 text-indigo-950 font-bold shadow-xs"
                          : "text-[#5C5B57] hover:bg-[#EAE6DF]/50 border border-transparent"
                      }`}
                    >
                      <div className="flex items-center gap-1.5 min-w-0 pr-1">
                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-300'}`} />
                        <span className="truncate">{chat.title || '새로운 대화'}</span>
                      </div>
                      {isActive && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-indigo-600 text-white font-bold rounded-md shrink-0 font-mono shadow-2xs">
                          대화중 ✨
                        </span>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="p-3 border-t border-[#EAE6DF] bg-white">
            <div className="flex items-center gap-2 p-1.5 rounded-lg bg-[#FAF9F6] border border-[#EAE6DF] mb-2">
              <div className="w-7 h-7 rounded-full bg-[#FAF9F6] border border-[#EAE6DF] flex items-center justify-center text-[#5C5B57] font-mono text-[11px] font-bold">A</div>
              <div className="truncate flex-1 min-w-0">
                <p className="text-xs font-semibold text-[#1D1D1F] truncate">최고 운영자</p>
                <p className="text-[10px] text-[#86868B] font-mono truncate">@admin</p>
              </div>
            </div>
            <button onClick={handleLogout} className="w-full py-1.5 px-2 bg-[#FAF9F6] hover:bg-rose-50 border border-[#EAE6DF] hover:border-rose-200 rounded-lg text-[10px] font-medium text-[#5C5B57] hover:text-rose-700 flex items-center justify-center gap-1 transition-colors">
              <LogOut className="w-3 h-3" /> 로그아웃
            </button>
          </div>
        </aside>

        {/* 2. Admin Center Main (Global Dashboard or Dev Hub) */}
        {mainNavTab === "dev" ? (
          <div className="flex-1 flex flex-col h-screen overflow-hidden">
            <DevCodeHubScreen
              selectedCodeId={selectedDevCodeId}
              onSelectCode={setSelectedDevCodeId}
            />
          </div>
        ) : (
          <main className="flex-1 flex flex-col h-screen overflow-y-auto bg-white border-r border-[#EAE6DF] p-6 relative">
            <div className="max-w-4xl mx-auto w-full space-y-6">
              <div className="space-y-1">
                <h2 className="text-2xl font-bold text-[#1D1D1F]">시스템 통합 모니터링</h2>
                <p className="text-sm text-[#86868B]">모든 사용자의 대화 통계 및 AI 리소스 사용 현황을 실시간으로 파악합니다.</p>
              </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="p-5 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-3xl text-white shadow-lg shadow-indigo-200">
                <Activity className="w-6 h-6 mb-3 opacity-80" />
                <p className="text-xs font-medium opacity-80">활성 엔진</p>
                <p className="text-lg font-bold truncate">{modelName || "Qwen 4B"}</p>
              </div>
              <div className="p-5 bg-white border border-[#EAE6DF] rounded-3xl shadow-sm">
                <Users className="w-6 h-6 mb-3 text-emerald-500" />
                <p className="text-xs font-medium text-[#86868B]">등록된 사용자</p>
                <p className="text-lg font-bold text-[#1D1D1F]">{globalStats?.users?.length || 0} 명</p>
              </div>
              <div className="p-5 bg-white border border-[#EAE6DF] rounded-3xl shadow-sm">
                <MessageSquare className="w-6 h-6 mb-3 text-blue-500" />
                <p className="text-xs font-medium text-[#86868B]">총 대화방 수</p>
                <p className="text-lg font-bold text-[#1D1D1F]">{globalStats?.users?.reduce((acc: any, u: any) => acc + u.totalChats, 0) || 0} 개</p>
              </div>
            </div>

            <div className="p-6 bg-[#FAF9F6] border border-[#EAE6DF] rounded-3xl space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#1D1D1F]">하이브리드 라우팅 및 할당량 관리</h3>
                  <p className="text-xs text-[#86868B]">유저당 하루에 허용할 프리미엄 GPT 호출 횟수를 설정합니다.</p>
                </div>
                <div className="flex items-center gap-3">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={hybridModeEnabled}
                      onChange={async (e) => {
                        const checked = e.target.checked;
                        setHybridModeEnabled(checked);
                        try {
                          await fetch("/api/lmstudio/config", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ hybridModeEnabled: checked, dailyGptQuota })
                          });
                          fetchGlobalStats();
                        } catch (err) { }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-[#EAE6DF] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number" min="0" value={dailyGptQuota}
                      onChange={(e) => setDailyGptQuota(parseInt(e.target.value))}
                      className="w-20 p-2 bg-white border border-[#EAE6DF] rounded-xl text-sm text-center font-mono focus:border-emerald-400 focus:outline-none"
                    />
                    <button
                      onClick={async () => {
                        try {
                          await fetch("/api/lmstudio/config", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ dailyGptQuota, hybridModeEnabled })
                          });
                          alert("저장되었습니다!");
                          fetchGlobalStats();
                        } catch (err) { }
                      }}
                      className="px-4 py-2 bg-[#1D1D1F] hover:bg-black text-white rounded-xl text-xs font-semibold transition-colors shadow-sm"
                    >
                      저장
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#1D1D1F]">사용자별 일일 쿼터 소진 현황</h3>
                <button onClick={fetchGlobalStats} className="text-[10px] text-indigo-600 font-bold hover:underline">새로고침</button>
              </div>
              <div className="border border-[#EAE6DF] rounded-2xl overflow-hidden shadow-sm bg-white">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF9F6] text-[#86868B] border-b border-[#EAE6DF]">
                    <tr>
                      <th className="p-3 font-semibold">유저</th>
                      <th className="p-3 font-semibold text-center">총 대화방</th>
                      <th className="p-3 font-semibold w-1/2">오늘 GPT 사용 현황 (한도: {globalStats?.settings?.dailyGptQuota || dailyGptQuota}회)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EAE6DF]">
                    {globalStats?.users?.map((u: any) => {
                      const quota = globalStats?.settings?.dailyGptQuota || dailyGptQuota || 30;
                      const usage = u.gptUsageCount || 0;
                      const percentage = Math.min((usage / quota) * 100, 100);
                      const isExhausted = usage >= quota;

                      return (
                        <tr key={u.id} className="hover:bg-[#FAF9F6] transition-colors">
                          <td className="p-3">
                            <div className="font-bold text-[#1D1D1F]">{u.displayName}</div>
                            <div className="text-[10px] font-mono text-[#86868B]">@{u.username}</div>
                          </td>
                          <td className="p-3 text-center font-mono text-[#1D1D1F]">{u.totalChats}</td>
                          <td className="p-3">
                            {hybridModeEnabled ? (
                              <div className="space-y-1.5">
                                <div className="flex justify-between text-[10px] text-[#86868B] font-medium">
                                  <span>{usage} 회 사용</span>
                                  <span className={isExhausted ? "text-rose-500 font-bold" : ""}>
                                    {isExhausted ? "한도 초과" : `${quota - usage} 회 남음`}
                                  </span>
                                </div>
                                <div className="h-2 w-full bg-[#EAE6DF] rounded-full overflow-hidden">
                                  <div
                                    className={`h-full transition-all duration-1000 ${isExhausted ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-400 to-emerald-500'}`}
                                    style={{ width: `${percentage}%` }}
                                  />
                                </div>
                              </div>
                            ) : (
                              <div className="text-[10px] text-[#B0ACA5] text-center">하이브리드 모드 꺼짐</div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            {/* Live Chat Monitoring Feed */}
            <div className="space-y-3 pt-6 border-t border-[#EAE6DF]">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#1D1D1F] flex items-center gap-2">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                    </span>
                    실시간 대화 모니터링
                  </h3>
                  <p className="text-[10px] text-[#86868B] mt-0.5">새로고침 없이 5초마다 최신 대화가 자동으로 업데이트됩니다.</p>
                </div>
                <div className="flex bg-[#EAE6DF] p-1 rounded-xl shadow-inner">
                  <button onClick={() => setMonitoringTab("rooms")} className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${monitoringTab === "rooms" ? "bg-white shadow-sm text-[#1D1D1F]" : "text-[#86868B] hover:text-[#5C5B57]"}`}>대화방 뷰</button>
                  <button onClick={() => setMonitoringTab("messages")} className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all ${monitoringTab === "messages" ? "bg-white shadow-sm text-[#1D1D1F]" : "text-[#86868B] hover:text-[#5C5B57]"}`}>메시지 뷰</button>
                </div>
              </div>

              {monitoringTab === "rooms" ? (
                <>
                  <div className="space-y-8">
                    {Object.entries(
                      adminChats.reduce((acc: any, chat) => {
                        const lastMsgTime = chat.messages?.length > 0 ? chat.messages[chat.messages.length - 1].timestamp : chat.createdAt;
                        const date = new Date(lastMsgTime).toLocaleDateString();
                        if (!acc[date]) acc[date] = [];
                        acc[date].push(chat);
                        return acc;
                      }, {})
                    )
                    .sort((a: any, b: any) => new Date(b[0]).getTime() - new Date(a[0]).getTime())
                    .map(([date, chatsArr]: any) => (
                      <div key={date} className="space-y-4">
                        <h4 className="text-sm font-bold text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-lg inline-block">{date}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {chatsArr
                            .sort((a: any, b: any) => {
                              const aTime = a.messages?.length > 0 ? a.messages[a.messages.length - 1].timestamp : a.createdAt;
                              const bTime = b.messages?.length > 0 ? b.messages[b.messages.length - 1].timestamp : b.createdAt;
                              return new Date(bTime).getTime() - new Date(aTime).getTime();
                            })
                            .map((chat: any) => {
                            const lastMsg = chat.messages?.length > 0 ? chat.messages[chat.messages.length - 1] : null;
                            const isApi = chat.title === "아두이노 소다봇 대화";
                            return (
                              <div 
                                key={chat.id} 
                                onClick={() => setMonitoringChatId(chat.id)}
                                className="bg-white border border-[#EAE6DF] hover:border-[#9C282C] rounded-2xl p-4 shadow-sm hover:shadow-[0_4px_16px_rgba(156,40,44,0.03)] transition-all cursor-pointer group flex flex-col justify-between"
                              >
                                <div>
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-1.5 truncate max-w-[60%]">
                                      <span className="text-[10px] font-bold px-2 py-0.5 bg-gray-100 text-gray-700 rounded-full truncate shrink-0">
                                        @{chat.username}
                                      </span>
                                      {isApi ? (
                                        <span className="px-1.5 py-0.5 bg-orange-100 text-orange-700 text-[9px] font-bold rounded-md shrink-0">API</span>
                                      ) : (
                                        <span className="px-1.5 py-0.5 bg-blue-100 text-blue-700 text-[9px] font-bold rounded-md shrink-0">WEB</span>
                                      )}
                                    </div>
                                    <span className="text-[10px] text-[#86868B] font-mono shrink-0">
                                      {lastMsg ? new Date(lastMsg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ""}
                                    </span>
                                  </div>
                                  <h4 className="text-xs font-semibold text-[#1D1D1F] truncate pr-2 mb-2">{chat.title}</h4>
                                  <div className="text-[11px] text-[#5C5B57] line-clamp-3 leading-relaxed bg-[#FAF9F6] p-2 rounded-xl">
                                    {lastMsg ? (
                                      <div className="flex flex-col gap-1">
                                        <span className={lastMsg.sender === "user" ? "font-semibold" : ""}>
                                          {lastMsg.sender === "user" ? "U: " : "A: "}{lastMsg.text}
                                        </span>
                                        {lastMsg.modelUsed && <span className="text-[9px] text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded self-start truncate max-w-full">🤖 {lastMsg.modelUsed}</span>}
                                      </div>
                                    ) : (
                                      <span className="italic text-[#86868B]">아직 메시지가 없습니다.</span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                  {adminChats.length === 0 && (
                    <div className="text-center py-10 text-xs text-[#86868B] bg-[#FAF9F6] rounded-2xl border border-[#EAE6DF] border-dashed">
                      진행 중인 대화가 없습니다.
                    </div>
                  )}
                </>
              ) : (
                <div className="bg-white border border-[#EAE6DF] rounded-2xl shadow-sm h-[600px] overflow-y-auto flex flex-col">
                  {(() => {
                    const allMessages = adminChats.flatMap((chat: any) => 
                      (chat.messages || []).map((msg: any, index: number) => ({
                        ...msg,
                        chatId: chat.id,
                        chatTitle: chat.title,
                        username: chat.username,
                        isApi: chat.title === "아두이노 소다봇 대화",
                        msgIndex: index
                      }))
                    ).sort((a: any, b: any) => {
                      const timeDiff = new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
                      if (timeDiff !== 0) return timeDiff;
                      return b.msgIndex - a.msgIndex;
                    });

                    if (allMessages.length === 0) {
                      return (
                        <div className="m-auto text-center py-10 text-xs text-[#86868B]">
                          진행 중인 메시지가 없습니다.
                        </div>
                      )
                    }

                    return (
                      <div className="flex flex-col">
                        {allMessages.map((msg: any) => (
                          <div key={`${msg.chatId}-${msg.id}`} onClick={() => setMonitoringChatId(msg.chatId)} className="flex gap-4 p-4 hover:bg-[#FAF9F6] transition-colors border-b border-[#EAE6DF] cursor-pointer group">
                            <div className="shrink-0 w-12 text-center space-y-1">
                              <div className="text-[10px] font-bold text-gray-700 bg-gray-100 rounded-md py-0.5 px-1 truncate">@{msg.username}</div>
                              {msg.isApi ? (
                                <div className="text-[9px] font-bold text-orange-700 bg-orange-100 rounded">API</div>
                              ) : (
                                <div className="text-[9px] font-bold text-blue-700 bg-blue-100 rounded">WEB</div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1.5">
                                <span className={`text-xs font-bold ${msg.sender === "user" ? "text-[#1D1D1F]" : "text-[#9C282C]"}`}>
                                  {msg.sender === "user" ? "User" : "AI"}
                                </span>
                                <span className="text-[10px] text-[#86868B] font-mono group-hover:text-indigo-600 transition-colors">
                                  {new Date(msg.timestamp).toLocaleString()}
                                </span>
                                {msg.modelUsed && <span className="text-[9px] text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded ml-auto shrink-0">🤖 {msg.modelUsed}</span>}
                              </div>
                              <div className={`text-xs leading-relaxed whitespace-pre-wrap ${msg.sender === "user" ? "text-[#1D1D1F] font-medium" : "text-[#5C5B57]"}`}>
                                {msg.text}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )
                  })()}
                </div>
              )}
            </div>

          </div>
        </main>
        )}

        {/* 3. Admin Right Sidebar (Mini Chat) */}
        <aside className="w-[340px] bg-[#FAF9F6] flex flex-col shrink-0 select-none">
          <header className="h-12 border-b border-[#EAE6DF] bg-white flex items-center justify-between px-4 shrink-0">
            <span className="text-xs font-bold text-[#1D1D1F]">미니 대화 테스트</span>
            <div className="flex items-center gap-1.5 text-[10px] text-[#86868B]">
              <span className={`w-1.5 h-1.5 rounded-full ${lmStudioConnected ? "bg-emerald-500" : "bg-rose-500"}`} />
              {lmStudioConnected ? "Connected" : "Offline"}
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {(!activeChat || activeChat.messages.length === 0) ? (
              <div className="text-center py-10 opacity-50">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 text-[#86868B]" />
                <p className="text-xs text-[#86868B]">새로운 대화를 시작하세요.</p>
              </div>
            ) : (
              activeChat.messages.map((msg: any, i: number) => (
                <div key={i} className={`flex gap-2 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl text-[11px] leading-relaxed shadow-sm ${msg.sender === "user" ? "bg-indigo-600 text-white rounded-br-none" : "bg-white border border-[#EAE6DF] text-[#1D1D1F] rounded-bl-none"}`}>
                    {msg.text}
                  </div>
                </div>
              ))
            )}
            {sending && (
              <div className="flex gap-2 justify-start">
                <div className="bg-white border border-[#EAE6DF] p-3 rounded-2xl rounded-bl-none shadow-sm">
                  <div className="flex gap-1">
                    <span className="w-1.5 h-1.5 bg-[#86868B] rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-[#86868B] rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></span>
                    <span className="w-1.5 h-1.5 bg-[#86868B] rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="p-3 bg-white border-t border-[#EAE6DF]">
            <form onSubmit={handleSendMessage} onKeyDown={preventImeSubmit} className="relative flex items-center">
              <input
                type="text"
                disabled={sending}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="테스트 메시지 입력..."
                className="w-full pl-3 pr-10 py-2.5 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-[11px] focus:outline-none focus:border-indigo-400"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || sending}
                className="absolute right-1.5 p-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-[#FAF9F6] text-white disabled:text-[#B0ACA5] rounded-lg transition-colors"
              >
                <Send className="w-3 h-3" />
              </button>
            </form>
          </div>
        </aside>

        {/* Modals for Admin */}
        {showAdminPanel && (
          <div className="fixed inset-0 bg-[#1D1D1F]/40 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in p-4">
            <div className="bg-white border border-[#EAE6DF] rounded-3xl w-full max-w-4xl shadow-2xl p-6 relative overflow-hidden flex flex-col max-h-[90vh]">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#FAF9F6] shrink-0">
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-[#1D1D1F] flex items-center gap-2">
                    <Users className="w-5 h-5 text-indigo-600" />
                    운영자 유저 및 실시간 대화 권한 관리
                  </h3>
                  <p className="text-xs text-[#86868B]">수업 진행 시 학생들의 대화 탭 잠금을 해제하거나 개별 권한을 부여할 수 있습니다.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleBatchToggleChatPermission(true)}
                    className="px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    전체 대화 오픈 (ON)
                  </button>
                  <button
                    onClick={() => handleBatchToggleChatPermission(false)}
                    className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    전체 대화 잠금 (OFF)
                  </button>
                  <button onClick={() => setShowAdminPanel(false)} className="text-xs text-[#86868B] hover:text-[#1D1D1F] bg-[#FAF9F6] px-3 py-1.5 rounded-full cursor-pointer">닫기 ✕</button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto py-4 space-y-6">
                {/* User Table */}
                <div className="border border-[#EAE6DF] rounded-2xl overflow-hidden shadow-sm">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#FAF9F6] text-[#86868B] border-b border-[#EAE6DF]">
                      <tr>
                        <th className="p-3 font-semibold">사용자 정보</th>
                        <th className="p-3 font-semibold text-center">대화 권한 (수업 제어)</th>
                        <th className="p-3 font-semibold">맞춤형 페르소나 설정 (System Prompt)</th>
                        <th className="p-3 font-semibold text-right">관리</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#EAE6DF]">
                      {adminUsers.map(u => {
                        const isUserAdmin = u.username === "admin" || u.role === "admin";
                        const hasChatAccess = isUserAdmin || Boolean(u.canAccessChat);
                        return (
                          <tr key={u.id} className="hover:bg-indigo-50/30 transition-colors align-top">
                            <td className="p-3">
                              <div className="flex items-center gap-1.5">
                                <span className="font-medium text-[#1D1D1F]">{u.displayName}</span>
                                {isUserAdmin && (
                                  <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">관리자</span>
                                )}
                              </div>
                              <div className="font-mono text-[11px] text-[#86868B]">@{u.username}</div>
                              <div className="font-mono text-[10px] text-[#5C5B57] mt-1 pt-1 border-t border-[#EAE6DF] w-fit">Key: {u.personalApiKey || "발급 안됨"}</div>
                            </td>
                            <td className="p-3 text-center">
                              {isUserAdmin ? (
                                <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-lg">
                                  항상 허용됨
                                </span>
                              ) : (
                                <button
                                  onClick={() => handleToggleChatPermission(u.id, Boolean(u.canAccessChat))}
                                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 mx-auto ${
                                    hasChatAccess
                                      ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs"
                                      : "bg-gray-100 hover:bg-gray-200 text-[#5C5B57] border border-[#EAE6DF]"
                                  }`}
                                >
                                  {hasChatAccess ? (
                                    <>
                                      <Unlock className="w-3 h-3" />
                                      대화 허용됨 (ON)
                                    </>
                                  ) : (
                                    <>
                                      <Lock className="w-3 h-3 text-gray-500" />
                                      잠김 (OFF)
                                    </>
                                  )}
                                </button>
                              )}
                            </td>
                            <td className="p-3">
                              <div className="flex flex-col gap-2">
                                <textarea
                                  defaultValue={u.persona || ""}
                                  onBlur={(e) => {
                                    if (e.target.value !== u.persona) {
                                      handleUpdatePersona(u.id, e.target.value);
                                    }
                                  }}
                                  placeholder="예: 이 유저에게는 초등학생 말투로 설명하세요."
                                  className="w-full h-20 p-2 bg-white border border-[#EAE6DF] rounded-xl text-[11px] focus:outline-none focus:border-indigo-400 resize-none"
                                />
                                <div className="text-[9px] text-[#86868B]">입력 후 포커스를 해제하면 자동 저장됩니다.</div>
                              </div>
                            </td>
                            <td className="p-3 text-right space-x-2 whitespace-nowrap">
                              <button onClick={() => handleGenerateApiKey(u.id)} className="px-2 py-1 bg-white border border-[#EAE6DF] hover:border-indigo-300 rounded-lg text-[10px] cursor-pointer">Key 재발급</button>
                              {u.id !== "user-1" && (
                                <button onClick={() => handleDeleteUser(u.id)} className="px-2 py-1 bg-white border border-[#EAE6DF] text-rose-500 rounded-lg text-[10px] cursor-pointer">삭제</button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {showSettings && (
          <div className="fixed inset-0 bg-[#1D1D1F]/40 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in p-4">
            <div className="bg-white border border-[#EAE6DF] rounded-3xl w-full max-w-lg shadow-2xl p-6 relative flex flex-col">
              <div className="flex items-center justify-between pb-4 border-b border-[#FAF9F6]">
                <h3 className="text-base font-bold text-[#1D1D1F]">서버 설정</h3>
                <button onClick={() => setShowSettings(false)} className="text-xs text-[#86868B] bg-[#FAF9F6] px-3 py-1.5 rounded-full">닫기 ✕</button>
              </div>
              <form onSubmit={handleSaveSettings} className="space-y-4 pt-4 overflow-y-auto max-h-[70vh]">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-[#1D1D1F]">기본 AI 제공자</label>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setAiProvider("local")} className={`flex-1 py-2 rounded-xl text-xs border ${aiProvider === "local" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-[#EAE6DF]"}`}>로컬 (LM Studio)</button>
                    <button type="button" onClick={() => setAiProvider("openai")} className={`flex-1 py-2 rounded-xl text-xs border ${aiProvider === "openai" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-[#EAE6DF]"}`}>클라우드 (OpenAI)</button>
                  </div>
                </div>
                {aiProvider === "openai" && (
                  <input type="password" value={openaiApiKey} onChange={e => setOpenaiApiKey(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs" placeholder="OpenAI API Key" />
                )}
                <input type="text" value={lmStudioUrl} onChange={e => setLmStudioUrl(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs" placeholder="LM Studio URL" />
                <input type="text" value={modelName} onChange={e => setModelName(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs" placeholder="모델명" />

                <div className="flex justify-between pt-2">
                  <button type="button" onClick={handleTestSettingsConnection} className="px-4 py-2 border rounded-xl text-xs">{testingConnection ? "테스트 중..." : "테스트"}</button>
                  <button type="submit" className="px-4 py-2 bg-black text-white rounded-xl text-xs">저장</button>
                </div>
                {testMessage && <p className="text-[10px] text-indigo-600">{testMessage}</p>}
              </form>
            </div>
          </div>
        )}

        {/* Monitoring Chat Detail Modal */}
        {monitoringChatId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-[#EAE6DF] overflow-hidden">
                  <div className="flex items-center justify-between p-5 border-b border-[#EAE6DF] bg-[#FAF9F6]">
                <div>
                  <h3 className="text-lg font-bold text-[#1D1D1F]">대화 상세 내역</h3>
                  <p className="text-xs text-[#86868B]">실시간 모니터링 중입니다.</p>
                </div>
                <button onClick={() => setMonitoringChatId(null)} className="p-2 text-[#86868B] hover:text-[#1D1D1F] hover:bg-[#EAE6DF] rounded-xl transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-white">
                {adminChats.find(c => c.id === monitoringChatId)?.messages.map((msg: any) => (
                  <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed ${msg.sender === "user"
                        ? "bg-[#2A2927] text-white rounded-tr-sm"
                        : "bg-[#FAF9F6] border border-[#EAE6DF] text-[#1D1D1F] rounded-tl-sm"
                      }`}>
                      <div className="whitespace-pre-wrap">{msg.text}</div>
                      <div className={`flex items-center justify-between text-[9px] mt-2 font-mono ${msg.sender === "user" ? "text-gray-400" : "text-[#86868B]"}`}>
                        <span>{new Date(msg.timestamp).toLocaleString()}</span>
                        {msg.modelUsed && <span className="text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded ml-2 truncate max-w-[120px]">🤖 {msg.modelUsed}</span>}
                      </div>
                    </div>
                  </div>
                ))}
                {adminChats.find(c => c.id === monitoringChatId)?.messages.length === 0 && (
                  <div className="text-center text-xs text-[#86868B] py-10">메시지가 없습니다.</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Admin Course Contents Manager Modal */}
        {showCourseManager && (
          <AdminCourseManagerModal
            token={token}
            onClose={() => setShowCourseManager(false)}
          />
        )}

      </div>
    );
  }

  // ===== NORMAL USER LAYOUT =====
  return (
    <div className="flex h-screen bg-[#FAF9F6] text-[#2A2927] overflow-hidden font-sans selection:bg-[#9C282C]/10 selection:text-[#9C282C]">

      {quickExprToast && (
        <div role="status" aria-live="polite" className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] max-w-xl rounded-xl bg-slate-900 px-5 py-3 text-sm text-white shadow-lg">
          {quickExprToast}
        </div>
      )}

      {/* 1. Sidebar Panel (Apple/Notion Vibe Left Section) */}
      <aside className="w-80 lg:w-[340px] border-r border-[#EAE6DF] bg-[#FAF9F6] flex flex-col justify-between shrink-0 h-screen select-none z-30">

        {/* Top Header & Main Navigation Tabs */}
        {/* Top Header & Main Navigation Tabs */}
        <div className="p-4 pb-2 flex flex-col gap-3">
          <div
            onClick={() => setCurrentView('welcome')}
            className="flex items-center gap-2 px-1 cursor-pointer group transition-transform active:scale-[0.98]"
            title="초기화면(홈)으로 이동"
          >
            <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shadow-sm group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-[#1D1D1F] tracking-tight group-hover:text-blue-600 transition-colors">SODABOT STUDIO</h2>
              <p className="text-[10px] text-[#86868B] font-medium">로봇 제작 & AI 코딩 스튜디오</p>
            </div>
          </div>

          {/* Primary Top Tab Switcher (1단계: 펌웨어 개발실 vs 2단계: 소다봇 제어 & AI 코딩) */}
          <div className="bg-[#EAE6DF]/70 p-1 rounded-2xl flex flex-col gap-1 shadow-inner mt-0.5">
            <button
              id="tab-btn-dev-code"
              onClick={() => {
                setMainNavTab("dev");
                setCurrentView("dev");
              }}
              className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                mainNavTab === "dev" && currentView !== "welcome"
                  ? "bg-white text-indigo-700 shadow-sm ring-1 ring-black/5"
                  : "text-[#5C5B57] hover:text-[#1D1D1F] hover:bg-white/50"
              }`}
            >
              <div className="flex items-center gap-2">
                <FolderCode className="w-4 h-4 text-indigo-600" />
                <span>1단계: 펌웨어 개발실</span>
              </div>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-indigo-50 text-indigo-600 font-extrabold font-mono">
                1~6주차
              </span>
            </button>

            <button
              id="tab-btn-chat-connect"
              onClick={() => {
                setMainNavTab("chat");
                if (currentView === "welcome" || currentView === "dev") {
                  setCurrentView(isSodabotConnected ? "chat" : "sodabot");
                }
              }}
              className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                mainNavTab === "chat" && currentView !== "welcome"
                  ? "bg-white text-[#1D1D1F] shadow-sm ring-1 ring-black/5"
                  : "text-[#5C5B57] hover:text-[#1D1D1F] hover:bg-white/50"
              }`}
            >
              <div className="flex items-center gap-2">
                <Smile className="w-4 h-4 text-emerald-600" />
                <span>2단계: 소다봇 제어 & AI 코딩</span>
              </div>
              {user.canAccessChat ? (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-600 font-extrabold flex items-center gap-0.5 font-mono">
                  7주차~
                </span>
              ) : (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-700 font-extrabold flex items-center gap-0.5 border border-amber-200">
                  <Lock className="w-2.5 h-2.5" />
                  승인 대기
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Sidebar Middle Section */}
        {mainNavTab === "dev" ? (
          <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1.5 scrollbar-thin">
            {/* Tree View Header */}
            <div className="flex items-center justify-between px-2 py-1.5 text-[10px] font-bold text-[#86868B] uppercase tracking-wider font-mono border-b border-[#EAE6DF] mb-1">
              <span className="flex items-center gap-1.5">
                <FolderCode className="w-3.5 h-3.5 text-indigo-600" />
                1~6주차 펌웨어 실습 코드
              </span>
              <button
                onClick={() => {
                  const devWeeks = Array.from(new Set(courseContents.filter(c => Number(c.week) <= 6).map(c => c.week)));
                  if (expandedWeeks.length === devWeeks.length) {
                    setExpandedWeeks([]);
                  } else {
                    setExpandedWeeks(devWeeks);
                  }
                }}
                className="text-[9px] text-[#86868B] hover:text-indigo-600 transition-colors cursor-pointer"
              >
                {expandedWeeks.length > 0 ? "모두 접기" : "모두 펼치기"}
              </button>
            </div>

            {/* Tree View Grouped by Week (1~6주차 전용) */}
            {Array.from(new Set(courseContents.filter(c => Number(c.week) <= 6).map(c => Number(c.week))))
              .sort((a, b) => Number(a) - Number(b))
              .map(weekNum => {
                const weekCodes = courseContents.filter(c => c.week === weekNum);
                const isExpanded = expandedWeeks.includes(weekNum);

                return (
                  <div key={weekNum} className="space-y-0.5">
                    {/* Folder Header Row */}
                    <button
                      onClick={() => {
                        setExpandedWeeks(prev =>
                          prev.includes(weekNum) ? prev.filter(w => w !== weekNum) : [...prev, weekNum]
                        );
                      }}
                      className="w-full text-left px-2 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between text-[#1D1D1F] hover:bg-[#EAE6DF]/40 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-[#86868B] shrink-0" />
                        )}
                        <span className="truncate">{weekNum}주차 실습</span>
                      </div>
                    </button>

                    {/* File Children Rows */}
                    {isExpanded && (
                      <div className="pl-4 space-y-0.5 border-l-2 border-indigo-100 ml-3.5 my-1">
                        {weekCodes.map(codeItem => {
                          const isSelected = selectedDevCodeId === codeItem.id && mainNavTab === 'dev';
                          const isInteractive = codeItem.contentType === 'interactive' || codeItem.filename?.endsWith('.html');
                          const isCircuit = codeItem.contentType === 'circuit' || codeItem.title.includes('회로') || codeItem.title.includes('배선도');
                          const isEditor = codeItem.contentType === 'editor';
                          const ext = isInteractive ? '탐구' : (codeItem.filename ? (codeItem.filename.split('.').pop() || 'ino') : 'ino');

                          return (
                            <button
                              key={codeItem.id}
                              onClick={() => {
                                setSelectedDevCodeId(codeItem.id);
                                setMainNavTab('dev');
                                setCurrentView('dev');
                              }}
                              className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs flex items-center justify-between transition-all cursor-pointer ${
                                isSelected && currentView === 'dev'
                                  ? 'bg-[#168571] text-white font-bold shadow-xs'
                                  : 'text-[#5C5B57] hover:bg-[#EAE6DF]/30 hover:text-[#1D1D1F]'
                              }`}
                            >
                              <div className="flex items-center gap-1.5 min-w-0 pr-1">
                                <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : isInteractive ? 'text-[#168571]' : 'text-indigo-500'}`} />
                                <span className="truncate text-xs font-semibold">{codeItem.title}</span>
                              </div>
                              <span className={`text-[8px] px-1.5 py-0.5 rounded font-mono shrink-0 ${
                                isSelected
                                  ? isInteractive
                                    ? 'bg-[#E8F4EF] text-[#168571] font-extrabold'
                                    : isCircuit
                                    ? 'bg-emerald-100 text-emerald-800 font-extrabold'
                                    : isEditor
                                      ? 'bg-purple-100 text-purple-800 font-extrabold'
                                      : 'bg-indigo-100 text-indigo-800 font-extrabold'
                                  : isInteractive
                                    ? 'bg-[#E8F4EF] text-[#168571] border border-[#168571]/30 font-bold'
                                    : isCircuit
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                                      : isEditor
                                        ? 'bg-purple-50 text-purple-700 border border-purple-200/60 font-bold'
                                        : 'bg-[#EAE6DF]/60 text-[#86868B]'
                              }`}>
                                {ext}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
          </div>
        ) : (
          <>
            {user.canAccessChat ? (
              <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2.5 scrollbar-thin">
                {/* 소다봇 연결 상태 카드 (소다봇 제어 탭일 때만 2개 탭 바로 밑에 표시) */}
                <button
                  onClick={() => setCurrentView('sodabot')}
                  className={`w-full text-left bg-white hover:bg-[#FAF9F6] border rounded-2xl p-2.5 shadow-xs transition-all cursor-pointer group ${
                    currentView === 'sodabot' ? 'border-indigo-500 ring-2 ring-indigo-50 bg-indigo-50/20' : 'border-[#EAE6DF] hover:border-indigo-300'
                  }`}
                  title="클릭하여 소다봇 연결 및 펌웨어 관리 열기"
                >
                  <div className="flex items-center justify-between text-[10px] font-semibold text-[#86868B] font-mono mb-1.5 px-0.5">
                    <span className="group-hover:text-indigo-600 transition-colors flex items-center gap-1">
                      <span>소다봇 상태</span>
                      <ChevronRight className="w-2.5 h-2.5 opacity-50 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
                    </span>
                    {isSodabotConnected ? (
                      <span className="text-emerald-600 font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                        {connType === 'wifi' ? 'Wi-Fi 온라인' : connType === 'ble' ? 'BLE 온라인' : 'USB 온라인'}
                      </span>
                    ) : (
                      <span className="text-amber-600 font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        미연결 (클릭하여 연결)
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-base shrink-0 ${
                      isSodabotConnected 
                        ? connType === 'serial' ? 'bg-blue-50 border border-blue-200' : 'bg-emerald-50 border border-emerald-200'
                        : 'bg-[#FAF9F6] border border-[#EAE6DF] group-hover:border-indigo-200'
                    }`}>
                      {isSodabotConnected ? '🤖' : '💤'}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-bold text-[#1D1D1F] truncate group-hover:text-indigo-600 transition-colors">
                          {isSodabotConnected 
                            ? (localStorage.getItem(`sodabot_${user?.id || user?.username}_device_name`) || localStorage.getItem("sodabot_device_name") || (localStorage.getItem(`sodabot_${user?.id || user?.username}_custom_name`) ? `SODABOT_${localStorage.getItem(`sodabot_${user?.id || user?.username}_custom_name`)}` : 'SODABOT'))
                            : '소다봇 연결하기'}
                        </h5>
                        {isSodabotConnected && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
                      </div>
                      <p className="text-[10px] text-[#86868B] font-mono truncate">
                        {isSodabotConnected 
                          ? (connType === 'serial' ? 'USB @ 115200' : sodabotIp ? `IP: ${sodabotIp}` : 'Bluetooth LE')
                          : '클릭하여 Wi-Fi/BLE 연결'}
                      </p>
                    </div>
                  </div>
                </button>

                {/* 7~11주차 실습 & AI 연동 메뉴 (소다봇 미연결 시 잠금 처리) */}
                <div className="space-y-1 pb-1 pt-1 border-t border-[#EAE6DF]/70">
                  <div className="flex items-center justify-between px-2 py-1 text-[10px] font-bold text-[#86868B] uppercase tracking-wider font-mono">
                    <span className="flex items-center gap-1.5">
                      <FolderCode className="w-3 h-3 text-indigo-600" />
                      7~11주차 실습 & 연동
                    </span>
                    {!isSodabotConnected ? (
                      <span className="text-[9px] text-amber-600 font-extrabold flex items-center gap-0.5 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                        <Lock className="w-2.5 h-2.5" /> 연결 필요
                      </span>
                    ) : (
                      <span className="text-[9px] text-emerald-600 font-extrabold flex items-center gap-0.5 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                        <Unlock className="w-2.5 h-2.5" /> 연동됨
                      </span>
                    )}
                  </div>

                  {/* 7-8주차 실습 폴더 */}
                  <div className="space-y-0.5">
                    <button
                      onClick={() => setIsWeek67Expanded(!isWeek67Expanded)}
                      className="w-full text-left px-2 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between text-[#1D1D1F] hover:bg-[#EAE6DF]/40 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        {isWeek67Expanded ? (
                          <ChevronDown className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-[#86868B] shrink-0" />
                        )}
                        <span className="truncate">7-8주차 실습</span>
                      </div>
                    </button>

                    {isWeek67Expanded && (
                      <div className="pl-3.5 space-y-0.5 border-l-2 border-indigo-100 ml-3.5 my-1">
                        {/* 1. 소다봇 설정하기 */}
                        <button
                          onClick={() => {
                            if (!isSodabotConnected) {
                              alert("소다봇이 연결되지 않았습니다. 상단 '소다봇 상태' 카드를 눌러 먼저 기기를 연결해 주세요.");
                              setCurrentView('sodabot');
                              return;
                            }
                            setCurrentView('settings');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            !isSodabotConnected
                              ? 'text-[#A1A1A6] hover:bg-neutral-100/50 hover:text-neutral-700'
                              : currentView === 'settings'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Settings className={`w-3.5 h-3.5 shrink-0 ${isSodabotConnected ? (currentView === 'settings' ? 'text-blue-600' : 'text-neutral-600') : 'text-slate-400'}`} />
                            <span className="truncate text-xs">1. 소다봇 설정하기</span>
                          </div>
                          {!isSodabotConnected ? (
                            <Lock className="w-3 h-3 text-neutral-400 shrink-0" />
                          ) : (
                            <span className="text-[8px] text-blue-700 bg-blue-50 border border-blue-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                              설정
                            </span>
                          )}
                        </button>

                        {/* 2. 마이크 추가 배선도 */}
                        <button
                          onClick={() => {
                            setCurrentView('mic_circuit');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'mic_circuit'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <FileCode className={`w-3.5 h-3.5 shrink-0 ${currentView === 'mic_circuit' ? 'text-blue-600' : 'text-emerald-500'}`} />
                            <span className="truncate text-xs">2. 마이크 추가 배선도</span>
                          </div>
                          <span className="text-[8px] text-blue-700 bg-blue-50 border border-blue-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            배선도
                          </span>
                        </button>

                        <button
                          onClick={() => setCurrentView('mic_lab')}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${currentView === 'mic_lab' ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs' : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'}`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Code2 className="w-3.5 h-3.5 shrink-0 text-indigo-500" />
                            <span className="truncate text-xs">3. 마이크 배선 실습</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">7-3</span>
                        </button>

                        {/* 3. 마이크 입력 테스트 (soda-6-3) */}
                        <button
                          onClick={() => {
                            setCurrentView('firmware_v4');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'firmware_v4'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Code2 className={`w-3.5 h-3.5 shrink-0 ${currentView === 'firmware_v4' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">4. 마이크 입력 테스트</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            코드
                          </span>
                        </button>

                        {/* 4. 소다봇 친구설정 (sodabot_builder) */}
                        <button
                          onClick={() => {
                            setCurrentView('sodabot_builder');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'sodabot_builder'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Users className={`w-3.5 h-3.5 shrink-0 ${currentView === 'sodabot_builder' ? 'text-blue-600' : 'text-blue-500'}`} />
                            <span className="truncate text-xs">5. 소다봇 친구설정</span>
                          </div>
                          <span className="text-[8px] text-blue-700 bg-blue-50 border border-blue-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            설정
                          </span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* 9주차 실습 폴더 */}
                  <div className="space-y-0.5">
                    <button
                      onClick={() => setIsWeek8Expanded(!isWeek8Expanded)}
                      className="w-full text-left px-2 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between text-[#1D1D1F] hover:bg-[#EAE6DF]/40 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        {isWeek8Expanded ? (
                          <ChevronDown className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-[#86868B] shrink-0" />
                        )}
                        <span className="truncate">9주차 실습</span>
                      </div>
                    </button>

                    {isWeek8Expanded && (
                      <div className="pl-3.5 space-y-0.5 border-l-2 border-indigo-100 ml-3.5 my-1">
                        {/* 1. 9주차 기본 펌웨어 (soda-8-1) */}
                        <button
                          onClick={() => {
                            const userKey = user?.id || user?.username || 'default';
                            const ssid = localStorage.getItem(`sodabot_${userKey}_wifi_ssid`) || localStorage.getItem('sodabot_wifi_ssid') || '';
                            const customName = localStorage.getItem(`sodabot_${userKey}_custom_name`) || localStorage.getItem('sodabot_custom_name') || '';
                            if (!ssid || !customName) {
                              alert("⚠️ 소다봇 Wi-Fi 정보와 로봇 이름이 아직 설정되지 않았습니다.\n[소다봇 연결하기] 화면에서 먼저 정보를 입력해주세요!");
                              setCurrentView('sodabot');
                              return;
                            }
                            setCurrentView('firmware_v8');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'firmware_v8'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Code2 className={`w-3.5 h-3.5 shrink-0 ${currentView === 'firmware_v8' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">1. 소다봇 기본 펌웨어</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            8-1
                          </span>
                        </button>

                        {/* 2. 9주차 소다와 대화하기 (8-2) */}
                        <button
                          onClick={() => {
                            setCurrentView('chat');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'chat'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${currentView === 'chat' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">2. 소다와 대화하기</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            8-2
                          </span>
                        </button>

                        {/* 3. 9주차 소다봇 친구 & 1:1 메시지 (8-3) */}
                        <button
                          onClick={() => {
                            setCurrentView('friends');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'friends'
                              ? 'bg-indigo-50 text-indigo-900 font-bold border border-indigo-200 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Users className={`w-3.5 h-3.5 shrink-0 ${currentView === 'friends' ? 'text-indigo-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">3. 소다봇 친구 & 메시지</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            8-3
                          </span>
                        </button>

                      </div>
                    )}
                  </div>

                  {/* 10주차 실습 폴더 */}
                  <div className="space-y-0.5">
                    <button
                      onClick={() => setIsWeek9Expanded(!isWeek9Expanded)}
                      className="w-full text-left px-2 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between text-[#1D1D1F] hover:bg-[#EAE6DF]/40 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        {isWeek9Expanded ? (
                          <ChevronDown className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-[#86868B] shrink-0" />
                        )}
                        <span className="truncate">10주차 실습</span>
                      </div>
                    </button>

                    {isWeek9Expanded && (
                      <div className="pl-3.5 space-y-0.5 border-l-2 border-indigo-100 ml-3.5 my-1">
                        {/* 1. 10주차 모바일 소다봇 */}
                        <button
                          onClick={() => {
                            setCurrentView('mobile_guide');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'mobile_guide'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Smartphone className={`w-3.5 h-3.5 shrink-0 ${currentView === 'mobile_guide' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">1. 모바일 소다봇</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            10-1
                          </span>
                        </button>

                        {/* 2. 10주차 PCB 기본 펌웨어 */}
                        <button
                          onClick={() => {
                            const userKey = user?.id || user?.username || 'default';
                            const ssid = localStorage.getItem(`sodabot_${userKey}_wifi_ssid`) || localStorage.getItem('sodabot_wifi_ssid') || '';
                            const customName = localStorage.getItem(`sodabot_${userKey}_custom_name`) || localStorage.getItem('sodabot_custom_name') || '';
                            if (!ssid || !customName) {
                              alert("⚠️ 소다봇 Wi-Fi 정보와 로봇 이름이 아직 설정되지 않았습니다.\n[소다봇 연결하기] 화면에서 먼저 정보를 입력해주세요!");
                              setCurrentView('sodabot');
                              return;
                            }
                            setCurrentView('firmware_v9');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'firmware_v9'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Code2 className={`w-3.5 h-3.5 shrink-0 ${currentView === 'firmware_v9' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">2. 소다봇 PCB 기본 펌웨어</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            10-2
                          </span>
                        </button>

                        {/* 3. 10주차 소다봇 조립하기 */}
                        <button
                          onClick={() => {
                            setCurrentView('assembly_v9');
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                            currentView === 'assembly_v9'
                              ? 'bg-blue-50/70 text-blue-900 font-bold border border-blue-200/70 shadow-2xs'
                              : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Wrench className={`w-3.5 h-3.5 shrink-0 ${currentView === 'assembly_v9' ? 'text-blue-600' : 'text-indigo-500'}`} />
                            <span className="truncate text-xs">3. 소다봇 조립하기</span>
                          </div>
                          <span className="text-[8px] text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                            10-3
                          </span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* 11주차: AI 스킬 프로젝트 */}
                  <button
                    onClick={() => {
                      setCurrentView('ai_skills');
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between transition-all cursor-pointer ${
                      currentView === 'ai_skills'
                        ? 'bg-blue-50 text-blue-900 font-bold border border-blue-200 shadow-2xs'
                        : 'text-[#5C5B57] hover:bg-[#EAE6DF]/20 hover:text-[#1D1D1F]'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <Sparkles className={`w-3.5 h-3.5 shrink-0 ${currentView === 'ai_skills' ? 'text-blue-600' : 'text-blue-500'}`} />
                      <span className="truncate">11주차: AI 스킬 프로젝트</span>
                    </div>
                    <span className="text-[8px] text-blue-700 bg-blue-50 border border-blue-200/60 px-1.5 py-0.5 rounded font-mono font-semibold shrink-0">
                      11
                    </span>
                  </button>
                </div>

                {/* Chat Rooms List when in Chat View */}
                {currentView === 'chat' && (
                  <div className="pt-2 border-t border-[#EAE6DF] space-y-1.5 animate-fade-in">
                    <div className="flex items-center justify-between px-1 text-[10px] font-bold text-[#86868B] uppercase tracking-wider font-mono">
                      <span>대화 기록 ({chats.length})</span>
                      <button
                        onClick={handleCreateNewChat}
                        className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer flex items-center gap-0.5 transition-colors"
                        title="새로운 대화방 시작"
                      >
                        <Plus className="w-3 h-3" /> 새 대화
                      </button>
                    </div>

                    <div className="space-y-1 max-h-[240px] overflow-y-auto scrollbar-thin pr-0.5">
                      {chats.length === 0 ? (
                        <div className="p-2.5 text-center bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-[11px] text-[#86868B]">
                          대화 기록이 없습니다.
                        </div>
                      ) : (
                        chats.map(chat => {
                          const isActive = activeChat?.id === chat.id;
                          return (
                            <button
                              key={chat.id}
                              onClick={() => setActiveChatId(chat.id)}
                              className={`w-full text-left px-2.5 py-2 rounded-xl text-xs flex items-center justify-between transition-all cursor-pointer ${
                                isActive
                                  ? 'bg-indigo-50/90 border border-indigo-200 text-indigo-950 font-bold shadow-xs'
                                  : 'text-[#5C5B57] hover:bg-[#EAE6DF]/40 hover:text-[#1D1D1F] border border-transparent'
                              }`}
                            >
                              <div className="flex items-center gap-1.5 min-w-0 pr-1">
                                <span className={`w-2 h-2 rounded-full shrink-0 ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-300'}`} />
                                <span className="truncate">{chat.title || '새로운 대화'}</span>
                              </div>

                              {isActive ? (
                                <span className="text-[9px] px-1.5 py-0.5 bg-indigo-600 text-white font-bold rounded-md shrink-0 shadow-2xs font-mono">
                                  대화중 ✨
                                </span>
                              ) : (
                                <span className="text-[9px] text-[#86868B] font-mono shrink-0">
                                  {new Date(chat.createdAt).toLocaleDateString([], { month: 'numeric', day: 'numeric' })}
                                </span>
                              )}
                            </button>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex-1 p-4 flex flex-col justify-center items-center text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 shadow-sm">
                  <Lock className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-[#1D1D1F]">대화 기능 권한 대기 중</h4>
                  <p className="text-[10px] text-[#86868B] leading-relaxed">
                    선생님이 승인하면 자동으로 대화 목록과 연결 기능이 활성화됩니다.
                  </p>
                </div>
              </div>
            )}
          </>
        )}

        {/* Fixed Bottom Guide Card for Dev Tab */}
        {mainNavTab === "dev" && (
          <div className="px-1.5 pb-2 shrink-0">
            <div className="p-2.5 bg-white border border-[#EAE6DF] rounded-2xl space-y-2 shadow-xs">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-[9px] font-bold text-[#374151]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#168571] shrink-0" />
                  <span>펌웨어 업로드 가이드</span>
                </div>
                <span className="text-[8px] text-[#A2A3A5] font-mono shrink-0">아두이노 IDE</span>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center gap-1.5 px-1.5 py-1 rounded-xl bg-[#FAF9F6] border border-[#EAE6DF] min-h-7">
                  <span className="w-4 h-4 rounded-md bg-[#168571] text-white flex items-center justify-center text-[10px] font-bold shrink-0">1</span>
                  <span className="text-[9px] font-semibold text-[#374151] truncate">💾 [파일 저장] 또는 [코드 복사]</span>
                </div>
                <div className="flex items-center gap-1.5 px-1.5 py-1 rounded-xl bg-[#FAF9F6] border border-[#EAE6DF] min-h-7">
                  <span className="w-4 h-4 rounded-md bg-[#4B5563] text-white flex items-center justify-center text-[10px] font-bold shrink-0">2</span>
                  <span className="text-[9px] font-semibold text-[#374151] truncate">💻 아두이노 IDE에 붙여넣기</span>
                </div>
                <div className="flex items-center gap-1.5 px-1.5 py-1 rounded-xl bg-[#E8F4EF] border border-[#D3EAE2] min-h-7">
                  <span className="w-4 h-4 rounded-md bg-[#168571] text-white flex items-center justify-center text-[10px] font-bold shrink-0">3</span>
                  <span className="text-[9px] font-bold text-[#168571] truncate">⚡ [ ➔ ] 업로드 버튼 누르기!</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* User Info & Quick Control Footer */}
        <div className="p-3 border-t border-[#EAE6DF] bg-white space-y-2">
          <div className="flex items-center gap-2 p-1.5 rounded-lg bg-[#FAF9F6] border border-[#EAE6DF]">
            <div className="w-7 h-7 rounded-full bg-[#FAF9F6] border border-[#EAE6DF] flex items-center justify-center text-[#5C5B57] font-mono text-[11px] font-bold">
              {user.displayName.substring(0, 1)}
            </div>
            <div className="truncate flex-1 min-w-0">
              <p className="text-xs font-semibold text-[#1D1D1F] truncate">{user.displayName}</p>
              <p className="text-[10px] text-[#86868B] font-mono truncate">@{user.username}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-1.5 pt-0.5">
            <button
              id="sidebar-logout-btn"
              onClick={handleLogout}
              className="py-1.5 px-2 bg-[#FAF9F6] hover:bg-rose-50 border border-[#EAE6DF] hover:border-rose-200 rounded-lg text-[10px] font-medium text-[#5C5B57] hover:text-rose-700 flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <LogOut className="w-3 h-3" />
              로그아웃
            </button>
          </div>
        </div>
      </aside>

      {/* 2. Main Body Area */}
      {currentView === 'welcome' ? (
        <SodabotWelcomeScreen currentUser={user} />
      ) : mainNavTab === "dev" || currentView === "dev" ? (
        <DevCodeHubScreen
          selectedCodeId={selectedDevCodeId}
          onSelectCode={setSelectedDevCodeId}
        />
      ) : !user.canAccessChat ? (
        /* Locked Chat Splash View */
        <main className="flex-1 flex flex-col items-center justify-center h-screen bg-[#FAF9F6] p-6 text-center select-none relative overflow-hidden">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#EAE6DF_1px,transparent_1px),linear-gradient(to_bottom,#EAE6DF_1px,transparent_1px)] bg-[size:5rem_5rem] opacity-25 pointer-events-none" />

          <div className="max-w-md w-full bg-white border border-[#EAE6DF] rounded-3xl p-8 shadow-xl space-y-6 relative z-10 animate-fade-in">
            <div className="w-16 h-16 rounded-3xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 mx-auto shadow-sm">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 text-amber-700 rounded-full text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                선생님(관리자) 승인 대기 중
              </div>
              <h2 className="text-xl font-extrabold text-[#1D1D1F] tracking-tight">
                소다봇 제어 & AI 코딩 탭이 대기 중입니다
              </h2>
              <p className="text-xs text-[#5C5B57] leading-relaxed">
                현재 수업 커리큘럼에 따라 <strong>수업 & 펌웨어 개발실</strong>이 기본 오픈되어 있습니다.
                회로 조립과 코드를 먼저 학습해 주세요. 선생님이 권한을 승인하면 소다봇 연동 및 코딩 제어가 실시간으로 열립니다.
              </p>
            </div>

            <div className="p-4 bg-[#FAF9F6] border border-[#EAE6DF] rounded-2xl text-left space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-[#1D1D1F]">
                <span>실시간 권한 감지 중</span>
                <span className="text-[10px] text-emerald-600 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  동기화 활성
                </span>
              </div>
              <p className="text-[11px] text-[#86868B]">
                선생님이 관리자 화면에서 연동 권한을 승인하면 새로고침 없이 즉시 소다봇 제어가 활성화됩니다.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <button
                onClick={() => setMainNavTab("dev")}
                className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <FolderCode className="w-4 h-4" />
                수업 & 펌웨어 제작실로 이동
              </button>
              <button
                onClick={() => token && verifySession(token)}
                className="py-2.5 px-4 bg-white hover:bg-[#FAF9F6] border border-[#EAE6DF] text-[#1D1D1F] rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-[#86868B]" />
                연동 상태 확인
              </button>
            </div>
          </div>
        </main>
      ) : (
        /* Normal Chat / Sodabot Connect / Builder View */
        <main className="flex-1 flex flex-col h-screen overflow-hidden bg-white relative">
          {currentView === 'chat' ? (
            <>
              {/* Apple/Muji style Minimal Header */}
              {(() => {
                const latestSettings = getLatestFriendSettings();
                const botName = latestSettings.persona.name || "루미";
                const studentName = latestSettings.profile.userName || user?.displayName || "친구";
                const roleName = latestSettings.persona.role || "공부친구";
                const toneName = latestSettings.persona.tone || "친근한 친구말";
                const memoryCount = latestSettings.memories.length;

                return (
                  <header className="min-h-14 py-2 border-b border-[#EAE6DF] bg-white flex flex-wrap items-center justify-between px-6 shrink-0 z-10 select-none gap-3">
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#1D1D1F] tracking-tight">
                          소다와 대화하기
                        </span>
                        <span className="text-[#86868B] text-xs font-medium font-mono">
                          {activeChat ? `· ${activeChat.title}` : ""}
                        </span>
                      </div>

                      <span className="text-[#EAE6DF] text-sm hidden sm:inline">/</span>

                      {/* Friend Persona & Profile Summary Badge (Click to open settings) */}
                      <button
                        onClick={() => setCurrentView('settings')}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#FAF9F6] hover:bg-indigo-50/60 border border-[#EAE6DF] hover:border-indigo-300 text-[11px] text-[#5C5B57] hover:text-indigo-900 transition-all cursor-pointer shadow-2xs"
                        title="클릭하면 소다봇 친구 설정 및 프로필/기억 관리 화면으로 이동합니다"
                      >
                        <span className="font-semibold text-indigo-700">
                          {botName}
                        </span>
                        <span className="text-[#B0ACA5]">·</span>
                        <span>{roleName}</span>
                        <span className="text-[#B0ACA5]">·</span>
                        <span>{toneName}</span>
                        <span className="text-[#B0ACA5]">·</span>
                        <span className="font-mono text-indigo-600 font-semibold">기억 {memoryCount}개</span>
                        <Edit3 className="w-3 h-3 text-indigo-500 ml-0.5" />
                      </button>
                    </div>

                    {/* Actions: Clear Chat & SODABOT Connection Status */}
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleClearChat}
                        disabled={clearingChat}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-[#5C5B57] hover:text-rose-700 bg-[#FAF9F6] hover:bg-rose-50 border border-[#EAE6DF] hover:border-rose-200 rounded-full transition-all cursor-pointer shadow-2xs active:scale-95 disabled:cursor-wait disabled:opacity-60"
                        title="현재 대화방의 메시지 기록을 모두 초기화합니다"
                      >
                        <RotateCcw className={`w-3 h-3 text-[#86868B] group-hover:text-rose-600 ${clearingChat ? "animate-spin" : ""}`} />
                        <span>{clearingChat ? "초기화 중" : "대화 초기화"}</span>
                      </button>

                      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium transition-all ${
                        isSodabotConnected
                          ? "bg-emerald-50 border border-emerald-200 text-emerald-700"
                          : "bg-[#FAF9F6] border border-[#EAE6DF] text-[#86868B]"
                      }`}>
                        <span className={`w-2 h-2 rounded-full ${isSodabotConnected ? "bg-emerald-500 animate-pulse" : "bg-gray-300"}`} />
                        <span>
                          {isSodabotConnected
                            ? `SODABOT · ${botName} 연결됨`
                            : "SODABOT 연결 안 됨"}
                        </span>
                      </div>
                    </div>
                  </header>
                );
              })()}

              {/* Scrollable Conversation Arena */}
              <div className="flex-1 overflow-y-auto px-6 py-8 bg-[#FAF9F6]/50 relative">

                {/* Subtle elegant grid background lines */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#EAE6DF_1px,transparent_1px),linear-gradient(to_bottom,#EAE6DF_1px,transparent_1px)] bg-[size:5rem_5rem] opacity-20 pointer-events-none" />

                <div className="max-w-3xl mx-auto space-y-6 relative z-10 pb-8">

                  {/* A. Welcome Card */}
                  {(!activeChat || activeChat.messages.length === 0) ? (
                    <div className="py-12 space-y-8 animate-fade-in">

                      {/* Visual Accent Title */}
                      <div className="text-center space-y-3 max-w-lg mx-auto">
                        <div className="inline-flex items-center justify-center w-12 h-12 bg-white border border-[#EAE6DF] rounded-2xl text-indigo-600 shadow-sm mb-1">
                          <Sparkles className="w-5 h-5 animate-pulse" />
                        </div>
                        <h1 className="text-xl font-bold text-[#1D1D1F] tracking-tight">
                          안녕하세요, {getLatestFriendSettings().profile.userName || user?.displayName || "친구"}님!
                        </h1>
                        <p className="text-xs text-[#86868B] leading-relaxed">
                          웹 채팅과 실물 소다봇 음성 대화가 하나의 친구 기억으로 연결되어 있어요.<br />
                          오늘 어떤 이야기를 나누고 싶나요?
                        </p>
                      </div>

                      {/* Grid Suggestions */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                        {getDynamicActionCards().map((card, idx) => (
                          <div
                            key={idx}
                            onClick={card.onClick}
                            className="bg-white border border-[#EAE6DF] hover:border-indigo-400 rounded-2xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer text-left space-y-2 group active:scale-[0.99] hover:scale-[1.01]"
                          >
                            <h3 className="text-xs font-semibold text-[#1D1D1F] flex items-center justify-between">
                              {card.title}
                              <ArrowRight className="w-3.5 h-3.5 text-[#B0ACA5] group-hover:text-indigo-600 transition-colors" />
                            </h3>
                            <p className="text-[11px] text-[#86868B] leading-normal">{card.desc}</p>
                          </div>
                        ))}
                      </div>

                    </div>
                  ) : (

                    /* B. Unified Conversation Timeline */
                    <div className="space-y-6 animate-fade-in">
                      {activeChat.messages.map((msg) => {
                        const isUser = msg.sender === "user";
                        const isSodabotSource = msg.source === "sodabot";
                        const botName = user?.friendSettings?.persona?.name || user?.friendSettings?.persona?.robotName || "소다봇";

                        return (
                          <div
                            key={msg.id}
                            className={`flex ${isUser ? "justify-end" : "justify-start"} items-start gap-3`}
                          >
                            {/* Avatar for AI Friend */}
                            {!isUser && (
                              <div className="w-8 h-8 rounded-xl bg-white border border-indigo-200 flex items-center justify-center text-indigo-600 shrink-0 shadow-xs font-bold text-xs">
                                🤖
                              </div>
                            )}

                            {/* Message Bubble Box */}
                            <div className={`max-w-[80%] rounded-2xl p-3.5 text-xs leading-relaxed ${
                              isUser
                                ? "bg-[#2A2927] text-white rounded-tr-sm shadow-sm"
                                : "bg-white border border-[#EAE6DF] text-[#2A2927] rounded-tl-sm shadow-sm space-y-2"
                            }`}>

                              {/* Source Badge (Only for User Messages) */}
                              {isUser && (
                                <div className="flex items-center gap-1.5 mb-1.5">
                                  <span className={`text-[9px] px-1.5 py-0.5 rounded-md font-bold tracking-wider font-mono ${
                                    isSodabotSource
                                      ? "bg-indigo-500/30 text-indigo-200 border border-indigo-400/40"
                                      : "bg-zinc-700 text-zinc-300 border border-zinc-600"
                                  }`}>
                                    {isSodabotSource ? "🎙 SODABOT" : "⌨ WEB"}
                                  </span>
                                </div>
                              )}

                              {/* Message Text */}
                              <div className="whitespace-pre-wrap font-sans break-words antialiased leading-relaxed">
                                {msg.text}
                              </div>

                              {/* Bottom Metadata & Actions */}
                              <div className="flex items-center justify-between text-[10px] text-[#86868B] font-mono border-t border-[#FAF9F6] pt-1.5 mt-2 gap-2 flex-wrap">
                                <span>
                                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>

                                {/* Speak on Sodabot Button: Only for web-generated AI responses */}
                                {SHOW_SODABOT_VOICE_PLAYBACK && !isUser && !isSodabotSource && (
                                  <button
                                    type="button"
                                    disabled={!canReachSodabot || speakingMessageId !== null}
                                    onClick={async () => {
                                      if (!canReachSodabot) return;
                                      setSpeakingMessageId(msg.id);
                                      setQuickExprToast("🔊 소다봇 음성 생성·재생 중... 잠시 기다려 주세요.");
                                      try {
                                        await sendHardwareCommand('speak', msg.text, '음성 재생');
                                      } finally {
                                        setSpeakingMessageId(null);
                                      }
                                    }}
                                    className={`inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium rounded-md transition-all border ${
                                      canReachSodabot && speakingMessageId === null
                                        ? "text-indigo-600 bg-indigo-50 hover:bg-indigo-100 active:scale-95 border-indigo-200 cursor-pointer"
                                        : speakingMessageId === msg.id
                                          ? "text-indigo-600 bg-indigo-50 border-indigo-200 cursor-wait opacity-80"
                                          : "text-gray-400 bg-gray-50 border-gray-200 cursor-not-allowed opacity-60"
                                    }`}
                                    title={canReachSodabot ? "이미 생성된 답변을 실물 소다봇에서 음성으로 출력합니다" : "소다봇 연결 화면에서 먼저 연결해 주세요"}
                                  >
                                    <span>{speakingMessageId === msg.id ? "⏳ 소다봇 음성 재생 중..." : "🔊 소다봇으로 말하기"}</span>
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* Avatar for User */}
                            {isUser && (
                              <div className={`w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 font-bold font-mono text-[10px] ${
                                isSodabotSource
                                  ? "bg-indigo-900 border-indigo-600 text-indigo-200"
                                  : "bg-[#FAF9F6] border-[#EAE6DF] text-[#5C5B57]"
                              }`}>
                                {isSodabotSource ? '🎙' : (user?.displayName || '나').substring(0, 1)}
                              </div>
                            )}
                          </div>
                        );
                      })}

                      {/* Typing Loading Indicator */}
                      {sending && (
                        <div className="flex justify-start items-start gap-3">
                          <div className="w-8 h-8 rounded-xl bg-white border border-indigo-200 flex items-center justify-center text-indigo-600 shrink-0 shadow-xs animate-pulse font-bold text-xs">
                            🤖
                          </div>
                          <div className="bg-white border border-[#EAE6DF] rounded-2xl p-3.5 text-xs text-[#86868B] font-mono leading-relaxed shadow-sm flex items-center gap-2">
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                            <span>소다봇이 생각하고 있어요...</span>
                          </div>
                        </div>
                      )}

                      <div ref={chatEndRef} />
                    </div>
                  )}

                </div>
              </div>

              {/* C. Bottom Input Area */}
              <div className="p-4 border-t border-[#EAE6DF] bg-white z-10">
                <div className="max-w-3xl mx-auto space-y-2">

                  <form onSubmit={handleSendMessage} onKeyDown={preventImeSubmit} className="relative flex items-center">
                    <input
                      id="main-chat-input"
                      type="text"
                      required
                      disabled={sending}
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder="메시지를 입력하세요."
                      className="w-full pl-4 pr-12 py-3.5 bg-[#FAF9F6] border border-[#EAE6DF] focus:border-indigo-500 rounded-2xl text-xs font-sans focus:outline-none transition-all placeholder:text-[#B0ACA5] shadow-inner"
                    />

                    <button
                      id="send-message-btn"
                      type="submit"
                      disabled={!inputText.trim() || sending}
                      className="absolute right-2 p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-[#FAF9F6] text-white disabled:text-[#B0ACA5] rounded-xl transition-all cursor-pointer shadow-sm"
                      title="메시지 보내기"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>

            {/* Subtle footer credit notes */}
            <div className="flex justify-between items-center text-[10px] text-[#86868B] font-mono select-none px-1">
              <span>SODA TALK AI Assistant</span>
              <span>입력 완료 후 엔터를 누르면 전송됩니다.</span>
            </div>
          </div>
        </div>
          </>
        ) : currentView === 'ai_skills' ? (
          <SodaAiSkillScreen
            key={user?.id || "guest"}
            currentUser={user}
            onNavigateToChat={() => setCurrentView('chat')}
            isSodabotConnected={isSodabotConnected}
          />
        ) : currentView === 'mobile_guide' ? (
          <SodabotMobileGuideScreen currentUser={user} />
        ) : currentView === 'assembly_v9' ? (
          <SodabotAssemblyScreen onBackToFirmware={() => setCurrentView('firmware_v9')} />
        ) : currentView === 'friends' ? (
          <SodabotFriendsScreen
            currentUser={user}
            token={token}
            isSodabotConnected={isSodabotConnected}
            onBackToChat={() => setCurrentView('chat')}
          />
        ) : currentView === 'sodabot' ? (
          <SodabotConnectScreen currentUser={user} />
        ) : currentView === 'sodabot_builder' ? (
          <SodabotFriendSettingsScreen currentUser={user} />
        ) : currentView === 'mic_lab' ? (
          <iframe src="/simulations/mic-lab/index.html" title="7-3 마이크 배선 실습" className="flex-1 w-full h-full min-h-0 border-0" />
        ) : currentView === 'mic_circuit' ? (
          <div className="flex-1 flex flex-col h-screen overflow-y-auto bg-[#FAF9F6] p-4 sm:p-8 scrollbar-thin">
            <div className="max-w-4xl w-full mx-auto space-y-6 animate-fade-in">
              {/* Header */}
              <div className="flex items-center justify-between bg-white p-5 rounded-2xl border border-[#EAE6DF] shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-xl shrink-0">
                    🎙️
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-black text-[#1D1D1F] flex items-center gap-2">
                      <span>7-8주차: 마이크 추가 배선도</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono font-bold">
                        WEEK 06-07
                      </span>
                    </h2>
                    <p className="text-xs text-[#86868B]">
                      ESP32 Super Mini 보드와 I2S 원형 마이크 모듈의 안전한 3.3V 전원 및 핀 배선 가이드입니다.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href="/images/circuit_mic_i2s.jpg"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer text-decoration-none shadow-2xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>원본 크게보기</span>
                  </a>
                  <button
                    onClick={() => setCurrentView('settings')}
                    className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>1. 소다봇 설정하기</span>
                  </button>
                </div>
              </div>

              {/* Main Image Container */}
              <div className="bg-white rounded-3xl p-4 sm:p-6 border border-[#EAE6DF] shadow-sm space-y-4">
                <div className="flex items-center justify-between border-b border-[#FAF9F6] pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    <h3 className="text-sm font-bold text-[#1D1D1F]">
                      ESP32 Super Mini ↔ Mic 연결 핀맵 & 브레드보드 실물 배치
                    </h3>
                  </div>
                  <span className="text-[11px] font-mono text-[#86868B]">
                    circuit_mic_i2s.jpg
                  </span>
                </div>

                {/* High Resolution Image */}
                <div className="rounded-2xl overflow-hidden bg-neutral-50 border border-[#EAE6DF] flex items-center justify-center p-2">
                  <img
                    src="/images/circuit_mic_i2s.jpg"
                    alt="ESP32 Super Mini와 마이크 연결 핀맵 배선도"
                    className="w-full max-h-[640px] object-contain rounded-xl shadow-xs"
                  />
                </div>
              </div>

              {/* Pin Connection Table & Important Notes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-12">
                {/* Table Card */}
                <div className="bg-white p-5 rounded-2xl border border-[#EAE6DF] shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#1D1D1F] uppercase tracking-wider font-mono">
                    <Cpu className="w-4 h-4 text-indigo-600" />
                    <span>ESP32 Super Mini ↔ 마이크 핀맵</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-[#EAE6DF] text-[#86868B] font-semibold text-[11px]">
                          <th className="pb-2">ESP32 핀</th>
                          <th className="pb-2">기능</th>
                          <th className="pb-2">마이크 모듈</th>
                          <th className="pb-2">배선 색상</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#FAF9F6] text-[#1D1D1F] font-mono text-[11px]">
                        <tr>
                          <td className="py-2 text-rose-600 font-bold">3V3 (전원)</td>
                          <td className="py-2 text-neutral-600">VDD</td>
                          <td className="py-2 text-rose-600 font-bold">VDD (3.3V)</td>
                          <td className="py-2 text-rose-600">빨강</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-neutral-800 font-bold">GND</td>
                          <td className="py-2 text-neutral-600">GND</td>
                          <td className="py-2 text-neutral-800 font-bold">GND</td>
                          <td className="py-2 text-neutral-800">검정</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-emerald-600 font-bold">GPIO9</td>
                          <td className="py-2 text-neutral-600">SCK (BCLK)</td>
                          <td className="py-2 text-emerald-600 font-bold">SCK</td>
                          <td className="py-2 text-emerald-600">초록</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-blue-600 font-bold">GPIO10</td>
                          <td className="py-2 text-neutral-600">WS (LRCL)</td>
                          <td className="py-2 text-blue-600 font-bold">WS</td>
                          <td className="py-2 text-blue-600">파랑</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-amber-600 font-bold">GPIO8</td>
                          <td className="py-2 text-neutral-600">SD (DATA)</td>
                          <td className="py-2 text-amber-600 font-bold">SD</td>
                          <td className="py-2 text-amber-600">주황</td>
                        </tr>
                        <tr>
                          <td className="py-2 text-purple-600 font-bold">GND</td>
                          <td className="py-2 text-neutral-600">L/R 선택</td>
                          <td className="py-2 text-purple-600 font-bold">L/R (선택)</td>
                          <td className="py-2 text-purple-600">보라</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Notes Card */}
                <div className="bg-white p-5 rounded-2xl border border-[#EAE6DF] shadow-xs space-y-3 flex flex-col justify-between">
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#1D1D1F]">
                      <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center text-[10px] font-bold">!</span>
                      <span>핵심 주의사항 & 배선 팁</span>
                    </div>
                    <ul className="text-xs text-[#5C5B57] space-y-2 leading-relaxed">
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                        <span><strong className="text-rose-600">VDD는 반드시 3.3V에 연결합니다</strong>: 5V에 연결하지 마세요 (마이크 고장 방지).</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                        <span><strong>브레드보드 반대편 3.3V 레일 활용</strong>: 전원선과 신호선을 구분하여 배선이 깔끔해지고 실수가 줄어듭니다.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                        <span><strong>모든 GND는 공통(Common GND)으로 연결</strong>하여 안정적인 신호를 보장합니다.</span>
                      </li>
                    </ul>
                  </div>

                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
                    💡 <strong>배선 완료 후</strong>: 상단의 <strong>[1. 소다봇 설정하기]</strong> 버튼을 눌러 Wi-Fi 및 펌웨어를 빌드하세요!
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (currentView === 'firmware_v4' || currentView === 'firmware_v8' || currentView === 'firmware_v9') ? (
          <div className="flex-1 flex flex-col h-screen overflow-y-auto bg-[#FAF9F6] p-4 sm:p-8 scrollbar-thin">
            <div className="max-w-4xl w-full mx-auto space-y-6 animate-fade-in pb-16">
              {/* Header */}
              {(() => {
                const userKey = user?.id || user?.username || 'default';
                const userCustomName = localStorage.getItem(`sodabot_${userKey}_custom_name`) || localStorage.getItem('sodabot_custom_name') || '';
                const userSsid = localStorage.getItem(`sodabot_${userKey}_wifi_ssid`) || localStorage.getItem('sodabot_wifi_ssid') || '';
                const userPass = localStorage.getItem(`sodabot_${userKey}_wifi_password`) || localStorage.getItem('sodabot_wifi_password') || '';
                const userApiKey = user?.personalApiKey || localStorage.getItem(`sodabot_${userKey}_api_key`) || localStorage.getItem('sodabot_api_key') || 'sk-soda-33b8c4c9312d29b8a01f1803e890a758';
                const cleanRobotName = userCustomName.replace(/[^a-zA-Z0-9_-]/g, '') || (user?.displayName ? user.displayName.replace(/[^a-zA-Z0-9_-]/g, '') : 'ROBOT');

                const isWeek9 = currentView === 'firmware_v9';
                const isWeek8 = currentView === 'firmware_v8';
                let dynamicCode = isWeek9 ? soda91Code : isWeek8 ? soda81Code : soda63Code;
                if (isWeek8 || isWeek9) {
                  if (userSsid) {
                    dynamicCode = dynamicCode.replace(/const char\* ssid = ".*?";/, `const char* ssid = "${userSsid}";`);
                  }
                  if (userPass) {
                    dynamicCode = dynamicCode.replace(/const char\* password = ".*?";/, `const char* password = "${userPass}";`);
                  }
                  if (cleanRobotName) {
                    dynamicCode = dynamicCode.replace(/const char\* SODA_BLE_NAME = ".*?";/, `const char* SODA_BLE_NAME = "SODABOT_${cleanRobotName}";`);
                    dynamicCode = dynamicCode.replace(/BLEDevice::init\("SODABOT_.*?"\);/, `BLEDevice::init("SODABOT_${cleanRobotName}");`);
                  }
                  dynamicCode = dynamicCode.replace(/const char\* DEFAULT_SODA_API_KEY = ".*?";/, `const char* DEFAULT_SODA_API_KEY = "${userApiKey}";`);
                  const isHttps = window.location.protocol === 'https:';
                  const currentHost = (window.location.hostname && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1')
                    ? window.location.hostname
                    : 'sodabot.sodayeon.co.kr';
                  const currentPort = window.location.port ? parseInt(window.location.port, 10) : (isHttps ? 443 : 7989);

                  dynamicCode = dynamicCode.replace(/const char\* SODA_SERVER_HOST = ".*?";/, `const char* SODA_SERVER_HOST = "${currentHost}";`);
                  dynamicCode = dynamicCode.replace(/const uint16_t SODA_SERVER_PORT = \d+;/, `const uint16_t SODA_SERVER_PORT = ${currentPort};`);
                  dynamicCode = dynamicCode.replace(/const bool SODA_SERVER_HTTPS = (true|false);/, `const bool SODA_SERVER_HTTPS = ${isHttps ? 'true' : 'false'};`);
                }

                const fileBaseName = isWeek9 ? `soda-9-1_${cleanRobotName}` : isWeek8 ? `soda-8-1_${cleanRobotName}` : `soda-6-3_mic_test`;

                return (
                  <>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-white p-5 rounded-2xl border border-[#EAE6DF] shadow-xs gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-xl shrink-0">
                          {isWeek9 ? '⚡' : isWeek8 ? '🤖' : '🎙️'}
                        </div>
                        <div>
                          <h2 className="text-base sm:text-lg font-black text-[#1D1D1F] flex items-center gap-2 flex-wrap">
                            <span>{isWeek9 ? '10주차: 소다봇 PCB 기본 펌웨어' : isWeek8 ? '9주차: 소다봇 기본 펌웨어' : '7-8주차: 마이크 입력 테스트'}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-mono font-bold">
                              {isWeek9 ? '소다봇 PCB v1.1' : isWeek8 ? '소다봇 빌더 통합 v4' : '사운드 레벨 측정'}
                            </span>
                          </h2>
                          <p className="text-xs text-[#86868B]">
                            {isWeek9
                              ? '소다봇 전용 PCB(v1.1) 실습을 위한 펌웨어입니다. SODA-AIBOT PCB 배선(버튼 GPIO43), I2S 마이크/스피커, 2.0" LCD 및 실시간 음성 대화 기능이 통합되어 있습니다.'
                              : isWeek8
                              ? 'ESP32-S3 기반 BLE, Wi-Fi, 2.0" LCD, I2S 스피커/마이크, Push-to-Talk 실시간 음성인식, 실시간 시계(NTP) 및 커스텀 기능 통합 표준 아두이노 코드입니다.'
                              : '물리 버튼(GPIO 4)을 누르고 있는 동안에만 마이크가 활성화되어 소리 크기(VU 미터)를 2.0" LCD와 시리얼 모니터로 실시간 측정하는 7주차 마이크 테스트 실습 펌웨어입니다.'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(dynamicCode);
                            setCopiedFirmware(true);
                            setTimeout(() => setCopiedFirmware(false), 2000);
                          }}
                          className={`px-3.5 py-2 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                            copiedFirmware
                              ? 'bg-emerald-600 text-white'
                              : 'bg-blue-600 hover:bg-blue-700 text-white'
                          }`}
                        >
                          {copiedFirmware ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedFirmware ? "전체 복사 완료!" : "코드 전체 복사"}</span>
                        </button>

                        <button
                          onClick={() => {
                            const blob = new Blob([dynamicCode], { type: 'text/plain;charset=utf-8' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `${fileBaseName}.ino`;
                            a.click();
                            URL.revokeObjectURL(url);
                          }}
                          className="px-3.5 py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer border border-[#EAE6DF]"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>.ino 다운로드</span>
                        </button>
                      </div>
                    </div>

                    {/* Wi-Fi 및 로봇 이름 미설정 경고 배너 */}
                    {(!userSsid || !userCustomName) && (
                      <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center justify-between text-rose-900 text-xs shadow-xs gap-3">
                        <div className="flex items-center gap-2.5">
                          <span className="text-lg shrink-0">⚠️</span>
                          <div>
                            <p className="font-bold text-rose-950">소다봇 Wi-Fi 정보 또는 로봇 이름이 아직 설정되지 않았습니다.</p>
                            <p className="text-[11px] text-rose-800">설정 화면에서 Wi-Fi와 이름을 저장하면 내 소다봇 맞춤 코드로 자동 주입됩니다.</p>
                          </div>
                        </div>
                        <button
                          onClick={() => setCurrentView('sodabot')}
                          className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs shrink-0 transition-colors shadow-xs cursor-pointer"
                        >
                          ⚡ 소다봇 연결 및 설정하러 가기
                        </button>
                      </div>
                    )}

                    {/* Upload Checklist Alert */}
                    <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-2xl flex items-start gap-3 text-amber-900 text-xs shadow-2xs">
                      <span className="text-base shrink-0">⚠️</span>
                      <div className="space-y-1">
                        <p className="font-bold text-amber-950">
                          아두이노 IDE 업로드 전 필수 확인 사항 (ESP32-S3)
                        </p>
                        <p className="text-amber-800/90 leading-relaxed">
                          1. <strong>Tools &gt; USB CDC On Boot</strong> 설정을 반드시 <strong>"Enabled"</strong>로 변경해야 시리얼 및 정상 동작합니다.<br />
                          2. 보드: <strong>ESP32S3 Dev Module</strong> / Flash Mode: <strong>QIO 80MHz</strong> / Upload Speed: <strong>921600</strong><br />
                          3. 배선: LCD, I2S 스피커, I2S 마이크의 전원(3.3V) 및 GND가 올바르게 연결되어 있는지 확인하세요.
                        </p>
                      </div>
                    </div>

                    {/* Code Viewer Box */}
                    <div className="bg-[#1E1E1E] rounded-3xl border border-neutral-800 shadow-md overflow-hidden flex flex-col">
                      {/* Code Window Header */}
                      <div className="flex items-center justify-between px-4 py-3 bg-[#181818] border-b border-neutral-800 text-xs text-neutral-400">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
                          <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
                          <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
                          <span className="font-mono text-neutral-300 ml-2 font-bold flex items-center gap-1.5">
                            <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                            {fileBaseName}.ino
                          </span>
                        </div>

                        <div className="flex items-center gap-3 font-mono text-[11px]">
                          <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                            Arduino C++
                          </span>
                          <span>{dynamicCode.split('\n').length} lines</span>
                        </div>
                      </div>

                      {/* Code Content */}
                      <div className="p-4 overflow-x-auto max-h-[580px] scrollbar-thin text-neutral-200 font-mono text-xs leading-relaxed">
                        <pre className="m-0 select-text">
                          <code>{dynamicCode}</code>
                        </pre>
                      </div>
                    </div>
                  </>
                );
              })()}

              {/* Quick Pin Guide Footer */}
              <div className="bg-white p-5 rounded-2xl border border-[#EAE6DF] shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-[#1D1D1F]">
                  <Cpu className="w-4 h-4 text-indigo-600" />
                  <span>소다봇 v4 통합 하드웨어 핀맵 요약</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                    <div className="font-bold text-neutral-800 mb-1">🎙️ I2S 마이크</div>
                    <div className="text-[11px] font-mono text-neutral-600">SCK:9, WS:10, SD:8 (VDD 3.3V)</div>
                  </div>
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                    <div className="font-bold text-neutral-800 mb-1">🔊 I2S 스피커</div>
                    <div className="text-[11px] font-mono text-neutral-600">BCLK:5, LRC:3, DIN:44 (MAX98357A)</div>
                  </div>
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                    <div className="font-bold text-neutral-800 mb-1">🖥️ 2.0" ST7789 LCD</div>
                    <div className="text-[11px] font-mono text-neutral-600">MOSI:11, CLK:12, CS:13, DC:7, RST:6</div>
                  </div>
                  <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                    <div className="font-bold text-neutral-800 mb-1">🔘 물리 버튼</div>
                    <div className="text-[11px] font-mono text-neutral-600">GPIO 4 (내부 풀업)</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <SodabotSettingsScreen currentUser={user} />
        )}
      </main>
      )}




      {/* 4. Admin User Management Drawer/Modal */}
      {showAdminPanel && (
        <div className="fixed inset-0 bg-[#1D1D1F]/40 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in p-4">
          <div className="bg-white border border-[#EAE6DF] rounded-3xl w-full max-w-4xl shadow-2xl p-6 relative overflow-hidden flex flex-col max-h-[90vh]">

            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#FAF9F6] shrink-0">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-[#1D1D1F]">시스템 유저 및 API Key 관리 (운영자 전용)</h3>
              </div>
              <button
                onClick={() => setShowAdminPanel(false)}
                className="text-xs text-[#86868B] hover:text-[#1D1D1F] transition-colors cursor-pointer font-semibold bg-[#FAF9F6] px-3 py-1.5 rounded-full"
              >
                닫기 ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-6 scrollbar-thin pr-2">

              {adminSelectedUserStatsId && adminUserStats ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-4">
                    <button onClick={() => setAdminSelectedUserStatsId(null)} className="text-xs text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md font-semibold hover:bg-indigo-100 transition-colors">
                      ← 뒤로 가기
                    </button>
                    <h4 className="text-sm font-bold text-[#1D1D1F]">
                      {adminUserStats.user.displayName} (@{adminUserStats.user.username}) 대시보드
                    </h4>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-[#FAF9F6] border border-[#EAE6DF] rounded-2xl flex flex-col items-center justify-center gap-1">
                      <span className="text-xs font-bold text-[#86868B]">총 대화방 수</span>
                      <span className="text-2xl font-bold text-[#1D1D1F]">{adminUserStats.stats.totalChats}</span>
                    </div>
                    <div className="p-4 bg-[#FAF9F6] border border-[#EAE6DF] rounded-2xl flex flex-col items-center justify-center gap-1">
                      <span className="text-xs font-bold text-[#86868B]">총 메시지 교환 수</span>
                      <span className="text-2xl font-bold text-[#1D1D1F]">{adminUserStats.stats.totalMessages}</span>
                    </div>
                  </div>

                  <div className="p-4 bg-white border border-[#EAE6DF] rounded-2xl space-y-3">
                    <h5 className="text-xs font-bold text-[#1D1D1F]">오늘의 인공지능 사용 현황</h5>
                    {adminUserStats.settings.hybridModeEnabled ? (
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-[#86868B] font-medium">
                          <span>GPT 할당량 소진</span>
                          <span>{adminUserStats.user.gptUsageCount} / {adminUserStats.settings.dailyGptQuota} 회</span>
                        </div>
                        <div className="h-2 w-full bg-[#FAF9F6] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 transition-all duration-1000"
                            style={{ width: `${Math.min((adminUserStats.user.gptUsageCount / adminUserStats.settings.dailyGptQuota) * 100, 100)}%` }}
                          />
                        </div>
                        <p className="text-[10px] text-[#86868B] mt-1">
                          할당량 소진 후에는 자동으로 무제한 무료 로컬 모델(LM Studio)로 연결됩니다.
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-[#86868B]">하이브리드 모드가 비활성화되어 있습니다.</p>
                    )}
                  </div>
                </div>
              ) : adminSelectedUserId ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <button onClick={() => setAdminSelectedUserId(null)} className="text-xs text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md font-semibold hover:bg-indigo-100 transition-colors">
                      ← 뒤로 가기
                    </button>
                    <h4 className="text-sm font-bold text-[#1D1D1F]">
                      {adminUsers.find(u => u.id === adminSelectedUserId)?.displayName} 님의 대화 기록
                    </h4>
                  </div>
                  {adminChats.filter(c => c.userId === adminSelectedUserId).length === 0 ? (
                    <div className="text-center py-8 text-[#86868B] text-xs">대화 기록이 없습니다.</div>
                  ) : (
                    <div className="space-y-4">
                      {adminChats.filter(c => c.userId === adminSelectedUserId).map(chat => (
                        <div key={chat.id} className="border border-[#EAE6DF] rounded-xl overflow-hidden bg-white">
                          <div className="bg-[#FAF9F6] px-3 py-2 border-b border-[#EAE6DF] flex justify-between items-center">
                            <span className="text-xs font-bold text-[#1D1D1F]">{chat.title}</span>
                            <span className="text-[10px] text-[#86868B]">{new Date(chat.createdAt).toLocaleString()}</span>
                          </div>
                          <div className="p-3 space-y-3 max-h-60 overflow-y-auto scrollbar-thin">
                            {chat.messages.map((m: any) => (
                              <div key={m.id} className={`flex ${m.sender === 'user' || m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[80%] rounded-lg px-3 py-2 text-xs ${m.sender === 'user' || m.role === 'user' ? 'bg-indigo-50 text-indigo-900' : 'bg-[#F5F5F7] text-[#1D1D1F]'}`}>
                                  <div className="font-semibold text-[10px] mb-1 opacity-60">
                                    {m.sender === 'user' || m.role === 'user' ? 'User' : 'Assistant'}
                                  </div>
                                  <div className="whitespace-pre-wrap">{m.text || m.content}</div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {/* User List Table */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-[#1D1D1F]">등록된 사용자 목록</h4>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleBatchToggleChatPermission(true)}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <ShieldCheck className="w-3 h-3" />
                          전체 대화 오픈 (ON)
                        </button>
                        <button
                          type="button"
                          onClick={() => handleBatchToggleChatPermission(false)}
                          className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <ShieldAlert className="w-3 h-3" />
                          전체 대화 잠금 (OFF)
                        </button>
                      </div>
                    </div>
                    <div className="border border-[#EAE6DF] rounded-2xl overflow-hidden shadow-sm">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#FAF9F6] text-[#86868B] border-b border-[#EAE6DF]">
                          <tr>
                            <th className="p-3 font-semibold">ID (계정)</th>
                            <th className="p-3 font-semibold">이름</th>
                            <th className="p-3 font-semibold text-center">대화 권한 (수업 제어)</th>
                            <th className="p-3 font-semibold">API Key</th>
                            <th className="p-3 font-semibold text-right">관리 액션</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#EAE6DF] text-[#1D1D1F]">
                          {adminUsers.map(u => {
                            const isUserAdmin = u.username === "admin" || u.role === "admin";
                            const hasChatAccess = isUserAdmin || Boolean(u.canAccessChat);
                            return (
                              <tr key={u.id} className="hover:bg-indigo-50/30 transition-colors">
                                <td className="p-3 font-mono text-[11px] font-semibold">
                                  {u.username}
                                  {isUserAdmin && (
                                    <span className="ml-1.5 text-[9px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">관리자</span>
                                  )}
                                </td>
                                <td className="p-3 font-medium">{u.displayName}</td>
                                <td className="p-3 text-center">
                                  {isUserAdmin ? (
                                    <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg">
                                      항상 허용
                                    </span>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => handleToggleChatPermission(u.id, Boolean(u.canAccessChat))}
                                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer inline-flex items-center gap-1 ${
                                        hasChatAccess
                                          ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs"
                                          : "bg-gray-100 hover:bg-gray-200 text-[#5C5B57] border border-[#EAE6DF]"
                                      }`}
                                    >
                                      {hasChatAccess ? (
                                        <>
                                          <Unlock className="w-2.5 h-2.5" />
                                          허용됨 (ON)
                                        </>
                                      ) : (
                                        <>
                                          <Lock className="w-2.5 h-2.5 text-gray-500" />
                                          잠김 (OFF)
                                        </>
                                      )}
                                    </button>
                                  )}
                                </td>
                                <td className="p-3 font-mono text-[10px] text-[#5C5B57]">
                                  {u.personalApiKey ? (
                                    <div className="flex items-center gap-2">
                                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-md select-all">
                                        {u.personalApiKey}
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-[#B0ACA5]">발급 안됨</span>
                                  )}
                                </td>
                                <td className="p-3 text-right space-x-2">
                                  <button
                                    onClick={() => handleGenerateApiKey(u.id)}
                                    className="px-2.5 py-1.5 bg-white border border-[#EAE6DF] hover:border-indigo-300 hover:text-indigo-600 rounded-lg text-[10px] font-medium transition-colors inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    <Key className="w-3 h-3" /> Key 재발급
                                  </button>
                                  <button
                                    onClick={() => fetchUserStats(u.id)}
                                    className="px-2.5 py-1.5 bg-white border border-[#EAE6DF] hover:border-emerald-300 hover:text-emerald-600 text-emerald-600 rounded-lg text-[10px] font-medium transition-colors inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    <Activity className="w-3 h-3" /> 대시보드
                                  </button>
                                  <button
                                    onClick={() => setAdminSelectedUserId(u.id)}
                                    className="px-2.5 py-1.5 bg-white border border-[#EAE6DF] hover:border-blue-300 hover:text-blue-600 text-blue-500 rounded-lg text-[10px] font-medium transition-colors inline-flex items-center gap-1 cursor-pointer"
                                  >
                                    대화 보기
                                  </button>
                                  {u.id !== "user-1" && (
                                    <button
                                      onClick={() => handleDeleteUser(u.id)}
                                      className="px-2.5 py-1.5 bg-white border border-[#EAE6DF] hover:border-rose-300 hover:text-rose-600 text-rose-500 rounded-lg text-[10px] font-medium transition-colors inline-flex items-center gap-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3 h-3" /> 삭제
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Create User Form */}
                  <div className="space-y-3 pt-4 border-t border-[#EAE6DF] border-dashed">
                    <h4 className="text-sm font-bold text-[#1D1D1F] flex items-center gap-1.5">
                      <PlusCircle className="w-4 h-4 text-indigo-500" /> 신규 사용자 강제 생성
                    </h4>

                    <form onSubmit={handleCreateUser} className="bg-[#FAF9F6] p-4 rounded-2xl border border-[#EAE6DF] space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-semibold text-[#5C5B57]">로그인 ID</label>
                          <input
                            required value={newUsername} onChange={e => setNewUsername(e.target.value)}
                            className="w-full px-3 py-2 text-xs border border-[#EAE6DF] rounded-xl focus:outline-none focus:border-indigo-400 font-mono" placeholder="예: aiden"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-semibold text-[#5C5B57]">표시 이름</label>
                          <input
                            required value={newDisplayName} onChange={e => setNewDisplayName(e.target.value)}
                            className="w-full px-3 py-2 text-xs border border-[#EAE6DF] rounded-xl focus:outline-none focus:border-indigo-400" placeholder="예: 에이든"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-semibold text-[#5C5B57]">초기 비밀번호</label>
                          <input
                            type="text" required value={newPassword} onChange={e => setNewPassword(e.target.value)}
                            className="w-full px-3 py-2 text-xs border border-[#EAE6DF] rounded-xl focus:outline-none focus:border-indigo-400 font-mono" placeholder="password123"
                          />
                        </div>
                      </div>

                      {adminError && <p className="text-xs text-rose-500 font-medium">{adminError}</p>}

                      <div className="flex justify-end">
                        <button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors shadow-sm cursor-pointer">
                          사용자 등록
                        </button>
                      </div>
                    </form>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}


      {/* 5. Server Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-[#1D1D1F]/40 backdrop-blur-sm flex justify-center items-center z-50 animate-fade-in p-4">
          <div className="bg-white border border-[#EAE6DF] rounded-3xl w-full max-w-lg shadow-2xl p-6 relative overflow-hidden flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-[#FAF9F6] shrink-0">
              <div className="space-y-1">
                <h3 className="text-base font-bold text-[#1D1D1F]">서버 설정 (운영자 전용)</h3>
                <p className="text-xs text-[#86868B]">AI 엔진 라우팅 및 전역 설정을 변경합니다.</p>
              </div>
              <button
                onClick={() => setShowSettings(false)}
                className="text-xs text-[#86868B] hover:text-[#1D1D1F] transition-colors cursor-pointer font-semibold bg-[#FAF9F6] px-3 py-1.5 rounded-full"
              >
                닫기 ✕
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-5 pt-4 overflow-y-auto max-h-[70vh] pr-2 scrollbar-thin">
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#1D1D1F]">기본 AI 제공자</label>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setAiProvider("local")} className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-colors ${aiProvider === "local" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-[#EAE6DF] text-[#5C5B57] hover:bg-[#FAF9F6]"}`}>
                    LM Studio (로컬)
                  </button>
                  <button type="button" onClick={() => setAiProvider("openai")} className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-colors ${aiProvider === "openai" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-[#EAE6DF] text-[#5C5B57] hover:bg-[#FAF9F6]"}`}>
                    OpenAI (클라우드)
                  </button>
                </div>
              </div>

              {aiProvider === "openai" && (
                <div className="space-y-2 animate-fade-in">
                  <label className="text-xs font-bold text-[#1D1D1F]">OpenAI API Key</label>
                  <input type="password" value={openaiApiKey} onChange={e => setOpenaiApiKey(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs font-mono focus:border-indigo-400 focus:outline-none" placeholder="sk-..." />
                </div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#1D1D1F]">LM Studio URL</label>
                <input type="text" value={lmStudioUrl} onChange={e => setLmStudioUrl(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs font-mono focus:border-indigo-400 focus:outline-none" placeholder="https://granular-kindly-morally.ngrok-free.dev" />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-[#1D1D1F]">모델 식별자 (Model Name)</label>
                <input type="text" value={modelName} onChange={e => setModelName(e.target.value)} className="w-full p-3 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs focus:border-indigo-400 focus:outline-none" placeholder="llama-3-korean-bllossom-8b" />
              </div>

              <div className="flex items-center justify-between p-3 border border-[#EAE6DF] rounded-xl bg-[#FAF9F6]">
                <div className="space-y-0.5">
                  <p className="text-xs font-bold text-[#1D1D1F]">가상 에뮬레이터 모드 (Fallback)</p>
                  <p className="text-[10px] text-[#86868B]">엔진 오프라인 시 임시 더미 응답으로 대체합니다.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={fallbackMode} onChange={e => setFallbackMode(e.target.checked)} className="sr-only peer" />
                  <div className="w-9 h-5 bg-[#EAE6DF] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                </label>
              </div>

              <div className="space-y-3 pt-4 border-t border-[#EAE6DF] border-dashed">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-[#1D1D1F]">하이브리드 라우팅 모드 (비용 절감)</p>
                    <p className="text-[10px] text-[#86868B]">매일 첫 접속 몇 번은 GPT로, 이후엔 로컬 모델로 자동 전환합니다.</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={hybridModeEnabled} onChange={e => setHybridModeEnabled(e.target.checked)} className="sr-only peer" />
                    <div className="w-9 h-5 bg-[#EAE6DF] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                {hybridModeEnabled && (
                  <div className="space-y-2 animate-fade-in pl-2 border-l-2 border-emerald-500">
                    <label className="text-xs font-bold text-[#1D1D1F]">하루 무료 제공 GPT 횟수 (Daily Quota)</label>
                    <input type="number" min="0" value={dailyGptQuota} onChange={e => setDailyGptQuota(parseInt(e.target.value))} className="w-full p-2 bg-[#FAF9F6] border border-[#EAE6DF] rounded-xl text-xs focus:border-emerald-400 focus:outline-none" />
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center pt-2">
                <button type="button" onClick={handleTestSettingsConnection} disabled={testingConnection} className="px-4 py-2 bg-white border border-[#EAE6DF] hover:bg-[#FAF9F6] rounded-xl text-xs font-semibold text-[#5C5B57] transition-colors">
                  {testingConnection ? "연결 테스트 중..." : "연결 테스트"}
                </button>
                <button type="submit" className="px-5 py-2 bg-[#1D1D1F] hover:bg-black text-white rounded-xl text-xs font-semibold transition-colors shadow-md">
                  설정 저장
                </button>
              </div>
              {testMessage && <p className="text-[10px] text-indigo-600 font-mono mt-2">{testMessage}</p>}
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
